package com.sdpt.app.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.sdpt.app.R;
import com.sdpt.app.item.UserAssessItem;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/24.
 */
public class ResCommentAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<UserAssessItem> list;
    private UserAssessItem assessItem;

    public  ResCommentAdapter(Context context,ArrayList<UserAssessItem> list){
        this.context=context;
        this.list=list;
    }


    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        assessItem=list.get(position);
        if (convertView==null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.restaurant_comment_list_item, null);
            viewHolder=new ViewHolder();

            viewHolder.linear_pic= (LinearLayout) convertView.findViewById(R.id.linearLayout_resComment_pic);
            viewHolder.image_userPic= (ImageView) convertView.findViewById(R.id.image_resComment_userPic);
            viewHolder.text_userName= (TextView) convertView.findViewById(R.id.text_resComment_userName);
            viewHolder.text_assessTime= (TextView) convertView.findViewById(R.id.text_resComment_assessTime);
            viewHolder.ratingBar= (RatingBar) convertView.findViewById(R.id.ratingBar_resComment_listItem);
            viewHolder.text_comment= (TextView) convertView.findViewById(R.id.text_resComment_userAssess);

            convertView.setTag(viewHolder);
        }else {
            viewHolder= (ViewHolder) convertView.getTag();
        }

        //判断用户是否有头像
        if (TextUtils.isEmpty(assessItem.getUserPic())){
            viewHolder.linear_pic.setVisibility(View.GONE);
        }else {
            viewHolder.linear_pic.setVisibility(View.VISIBLE);
            Picasso.with(context).load(assessItem.getUserPic()).into(viewHolder.image_userPic);
        }
        viewHolder.text_userName.setText(assessItem.getUserName());
        viewHolder.text_assessTime.setText(assessItem.getUserAssessTime());
        viewHolder.ratingBar.setRating(Float.valueOf(assessItem.getRating()));
        //判断内容是否为空
        if (TextUtils.isEmpty(assessItem.getComment())){
            viewHolder.text_comment.setVisibility(View.GONE);
        }else {
            viewHolder.text_comment.setVisibility(View.VISIBLE);
            viewHolder.text_comment.setText(assessItem.getComment());
        }

        return convertView;
    }

    class ViewHolder{
        LinearLayout linear_pic;
        ImageView image_userPic;
        TextView text_userName;
        TextView text_assessTime;
        RatingBar ratingBar;
        TextView text_comment;
    }

}
