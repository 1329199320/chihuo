package com.sdpt.app.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.db.AddressDB;
import com.sdpt.app.item.MyAddressItem;

import java.util.ArrayList;

/*
* 地址显示列表
* */
public class MyAddressActivity extends AppCompatActivity {

    private FloatingActionButton fab; //添加地址按钮
    private ListView listView;
    private AddressDB addressDB;
    public static String TYPE_TO_ADD_ADDRESS ="type";
    public static int type_add=1;//添加地址
    public static int type_edit=2;//编辑地址
    private ArrayList<MyAddressItem> list;
    private MyAddressAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_address);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ColorDrawable colorDrawable=new ColorDrawable(0xff009688);
        ActionBar actionBar=this.getSupportActionBar();
        actionBar.setBackgroundDrawable(colorDrawable);

        init();
        initEvent();
    }

    @Override
    protected void onResume() {
        super.onResume();
        list=addressDB.selectAll();
        adapter.notifyDataSetChanged();
        adapter=new MyAddressAdapter(this,list);
        listView.setAdapter(adapter);
    }

    private void init(){
        fab = (FloatingActionButton) findViewById(R.id.fab);
        listView= (ListView) findViewById(R.id.list_myAddress);

        addressDB=AddressDB.getInstance(this);
        list=addressDB.selectAll();
    }
    private void initEvent(){

        adapter=new MyAddressAdapter(this,list);
        listView.setAdapter(adapter);

        //点击添加按钮
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MyAddressActivity.this,MyAddressAddActivity.class);
                intent.putExtra(TYPE_TO_ADD_ADDRESS,type_add);
                startActivity(intent);
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent=new Intent(MyAddressActivity.this,MyAddressAddActivity.class);
                intent.putExtra(TYPE_TO_ADD_ADDRESS,type_edit);
                intent.putExtra(Config.ADDRESS_ID,list.get(position).getId());
                startActivity(intent);
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
            break;
        }
        return super.onOptionsItemSelected(item);
    }


    class MyAddressAdapter extends BaseAdapter{

        private Context context;
        private ArrayList<MyAddressItem> list;

        public MyAddressAdapter(Context context,ArrayList<MyAddressItem> list){
            this.context=context;
            this.list=list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            MyAddressItem item=list.get(position);
            if (convertView==null){
                viewHolder=new ViewHolder();
                convertView= LayoutInflater.from(context).inflate(R.layout.my_address_list_item,null);
                viewHolder.text_name= (TextView) convertView.findViewById(R.id.text_myAddress_listItem_name);
                viewHolder.text_sex= (TextView) convertView.findViewById(R.id.text_myAddress_listItem_sex);
                viewHolder.text_phone= (TextView) convertView.findViewById(R.id.text_myAddress_listItem_phone);
                viewHolder.text_address= (TextView) convertView.findViewById(R.id.text_myAddress_listItem_address);
                viewHolder.text_addressDetail= (TextView) convertView.findViewById(R.id.text_myAddress_listItem_addressDetail);
                viewHolder.image_check= (ImageView) convertView.findViewById(R.id.image_myAddress_listItem_add);
                convertView.setTag(viewHolder);
            }else {
                viewHolder= (ViewHolder) convertView.getTag();
            }
            viewHolder.text_name.setText(item.getContactName());
            viewHolder.text_sex.setText(item.getSex());
            viewHolder.text_phone.setText(item.getPhone());
            viewHolder.text_address.setText(item.getAddress());
            viewHolder.text_addressDetail.setText(item.getAddressDetail());

            if (position==0){
                viewHolder.image_check.setVisibility(View.VISIBLE);
            }else {
                viewHolder.image_check.setVisibility(View.GONE);
            }

            return convertView;
        }

        class ViewHolder{
            TextView text_name;
            TextView text_sex;
            TextView text_phone;
            TextView text_address;
            TextView text_addressDetail;

            ImageView image_check;
        }

    }

}
