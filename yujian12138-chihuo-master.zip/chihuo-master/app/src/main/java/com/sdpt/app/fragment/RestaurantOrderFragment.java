package com.sdpt.app.fragment;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.HeaderViewListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.adapter.ResOrderLeftAdapter;
import com.sdpt.app.adapter.ResOrderRightAdapter;
import com.sdpt.app.adapter.SeparatedListAdapter;
import com.sdpt.app.item.ResOrderFoodItem;
import com.sdpt.app.model.ResOrderLeftListView;
import com.sdpt.app.model.ResOrderRightListView;
import com.sdpt.app.net.HttpCallBackListener;
import com.sdpt.app.net.NetConnection;
import com.sdpt.app.net.NetWorkState;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/12.
 */
public class RestaurantOrderFragment extends Fragment{

    private View rootView;
    private ResOrderLeftListView listView_left;
    private ResOrderRightListView listView_right;
    private TextView textView_tip;
    int firstListItem=0;
    private HeaderViewListAdapter headerViewListAdapter;

    private ArrayList<ResOrderRightAdapter> rightAdapterCount; //右边列表Adapter的总数
    private ArrayList<String> listHeaderData;
    private SeparatedListAdapter adapter_right;

    private static int BACKGROUND_COLOR=0;
    private static int BACKGROUND_COLOR_SELECTED=0;

    private String restaurantId=null;
    private ArrayList<ResOrderFoodItem> leftClassLists;
    private  ResOrderLeftAdapter adapter_left=null;
    private boolean isLoad=false;
    private ProgressDialog progressDialog;
    private ArrayList<ResOrderFoodItem> foodNetList=new ArrayList<>();
    private SeparatedListAdapter sparated_adapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView=inflater.inflate(R.layout.restaurant_order, container, false);

        progressDialog=new ProgressDialog(getActivity());
        progressDialog.show();

        initView();
        getFoodCatList();
        getFoodList();
        initEvent();

        return rootView;
    }

    private void initView(){
        listView_left= (ResOrderLeftListView) rootView.findViewById(R.id.listView_restaurantOrder_left);
        listView_right= (ResOrderRightListView) rootView.findViewById(R.id.listView_restaurantOrder_right);
//        textView_tip= (TextView) rootView.findViewById(R.id.textView_restaurantOrder_tip);
        restaurantId=getActivity().getIntent().getStringExtra(Config.RESTAURANT_ID);
        leftClassLists=new ArrayList<ResOrderFoodItem>();
    }


    private void initEvent(){
//        getFoodCatList();
        sparated_adapter=new SeparatedListAdapter(getActivity());
//        adapter_right=getRightAdapter();
//        adapter_right=sparated_adapter;
        adapter_left = new ResOrderLeftAdapter(getActivity(), leftClassLists);
        rightAdapterCount=new ArrayList<>();

        progressDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                listView_right.setAdapter(sparated_adapter);

            }
        });

        listView_left.setAdapter(adapter_left);


        BACKGROUND_COLOR=getResources().getColor(R.color.listBackColor);
        BACKGROUND_COLOR_SELECTED=getResources().getColor(R.color.listBackColor_selected);
        //左边的点击事件
        listView_left.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            View tempView; //Item的View
            TextView tempTextView;//Item 的textView控件

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int position, long l) {
                //点击时，左边Item背景和字体的变化

                for (int i = 0; i < listView_left.getCount(); i++) {
                    if (i == position) {
                        changeLeftBackgroundAndText(listView_left.getChildAt(i), true);
                    } else {
                        changeLeftBackgroundAndText(listView_left.getChildAt(i), false);
                    }
                }
                //左边点击时，右边的class项会移动到顶端
                int count = 0;
                if (position == 0) {
                    listView_right.setSelection(0);
                } else {
                    for (int m = 0; m <= position - 1; m++) {
                        count += getRightAdapterCount().get(m).getCount() + 1;
                    }
                    listView_right.setSelection(count);
                }

            }
        });
        //右边listView的滚动事件
        listView_right.setOnScrollListener(new AbsListView.OnScrollListener() {
            boolean isFirstScroll = false;
            int state = 0;

            @Override
            public void onScrollStateChanged(AbsListView absListView, int i) {
                state = i;
            }

            @Override
            public void onScroll(AbsListView absListView, int firstViewItem, int visibleItemCount,
                                 int totalItemCount) {
                int count = 0;
                int size = getRightAdapterCount().size();
                for (int i = 0; i < getRightAdapterCount().size(); i++) {
                    count += getRightAdapterCount().get(i).getCount();
                    if (firstViewItem >= 0
                            && firstViewItem <= getRightAdapterCount().get(0).getCount()) {
                        if (isFirstScroll) {
                            changeLeftBackgroundAndText(listView_left.getChildAt(0), true);
                            for (int m = 1; m < size; m++) {
                                changeLeftBackgroundAndText(listView_left.getChildAt(m), false);
                            }
                        }
                        System.out.println("listViewLeft first:" + listView_left.getAdapter().getItemId(0));
                        break;
                    } else if (i > 0 && firstViewItem >
                            (totalItemCount - getRightAdapterCount().get(size - 1).getCount()
                                    - size + 1)) {

                        changeLeftBackgroundAndText(listView_left.getChildAt(size - 1), true);
                        for (int n = 0; n < size - 1; n++) {

                            changeLeftBackgroundAndText(listView_left.getChildAt(n), false);
                        }

                        isFirstScroll = true;
                        System.out.println("--" + listView_left.getAdapter().getItemId(i));

                        break;
                    } else if (i > 0
                            && i <= (getRightAdapterCount().size() - 2)
                            && firstViewItem > count - getRightAdapterCount().get(i - 1).getCount()
                            && firstViewItem < count + getRightAdapterCount().get(i + 1).getCount()) {
                        for (int k = 0; k < size; k++) {
                            if (k == i) {

                                changeLeftBackgroundAndText(listView_left.getChildAt(k), true);
                            } else {
                                changeLeftBackgroundAndText(listView_left.getChildAt(k), false);

                            }
                        }
                        isFirstScroll = true;

                        break;
                    }

                }

            }

        });


    }
    //改变左边的背景颜色和文字背景
    private void changeLeftBackgroundAndText(View view,boolean isSelected){
        TextView textView= (TextView) view.findViewById(R.id.textView_resOrder_leftItem);
        if (isSelected){
            view.setBackgroundColor(BACKGROUND_COLOR_SELECTED);
            textView.setTextColor(Color.RED);
        }else {
            view.setBackgroundColor(BACKGROUND_COLOR);
            textView.setTextColor(Color.BLACK);
        }
    }
    //右边Adapter 过时
    private SeparatedListAdapter getRightAdapter(){
        SeparatedListAdapter sparated_adapter=new SeparatedListAdapter(getActivity());

        listHeaderData=getListHeaderData();
        rightAdapterCount=getRightAdapterCount();
        for (int i=0;i<listHeaderData.size();i++){
               sparated_adapter.addSection(listHeaderData.get(i), rightAdapterCount.get(i));

        }
        return sparated_adapter;
    }
    //右边listView header标题的集合
    private ArrayList<String> getListHeaderData(){
        ArrayList<String> data=new ArrayList<String>();

//        ArrayList<ResOrderFoodItem> listLeft=handleLeftData();
        ArrayList<ResOrderFoodItem> listLeft=leftClassLists;

        for (int i=0;i<leftClassLists.size();i++) {
            data.add(leftClassLists.get(i).getClassName());
        }
        return data;
    }
    //右边ItemAdapter的集合
    private ArrayList<ResOrderRightAdapter> getRightAdapterCount(){
        ArrayList<ResOrderRightAdapter> adapters=new ArrayList<ResOrderRightAdapter>();

        ArrayList<ResOrderFoodItem> list1=new ArrayList<>();
        list1.add(new ResOrderFoodItem(1,"原味",4));
        list1.add(new ResOrderFoodItem(2,"鸡蛋",12));
        list1.add(new ResOrderFoodItem(3,"火腿",6));
        list1.add(new ResOrderFoodItem(4,"生菜",2));
        ResOrderRightAdapter adapter1=new ResOrderRightAdapter(getActivity(),list1,rootView);
        adapters.add(adapter1);

//        ArrayList<ResOrderFoodItem> list2=new ArrayList<>();
//        list2.add(new ResOrderFoodItem(5,"鸡排",5));
//        list2.add(new ResOrderFoodItem(6,"培根",2));
//        list2.add(new ResOrderFoodItem(7,"青瓜",1));
//        ResOrderRightAdapter adapter2=new ResOrderRightAdapter(getActivity(),list2,rootView);
//        adapters.add(adapter2);
//
//        ArrayList<ResOrderFoodItem> list3=new ArrayList<>();
//        list3.add(new ResOrderFoodItem(8,"柠檬",8));
//        list3.add(new ResOrderFoodItem(9,"绿茶",8));
//        list3.add(new ResOrderFoodItem(10,"冻柠乐",5));
//        list3.add(new ResOrderFoodItem(11,"酸梅汤",5));
//        list3.add(new ResOrderFoodItem(11,"酸梅汤",5));
//        list3.add(new ResOrderFoodItem(11,"酸梅汤",5));
//        list3.add(new ResOrderFoodItem(11,"酸梅汤",5));
//        list3.add(new ResOrderFoodItem(11,"酸梅汤",5));
//        list3.add(new ResOrderFoodItem(11,"酸梅汤",5));
//        list3.add(new ResOrderFoodItem(12,"奶香绿茶",7));
//        list3.add(new ResOrderFoodItem(12,"奶香绿茶",7));
//
//        ResOrderRightAdapter adapter3=new ResOrderRightAdapter(getActivity(),list3,rootView);
//        adapters.add(adapter3);

        return adapters;
    }

    //左边数据
//    private ArrayList<ResOrderFoodItem> handleLeftData(){
////        String s="http://img4.imgtn.bdimg.com/it/u=312408706,1964216526&fm=21&gp=0.jpg";
//        ArrayList<ResOrderFoodItem> leftItems=new ArrayList<ResOrderFoodItem>();
////        leftItems.add(new ResOrderFoodItem(1,"销量排行"));
////        leftItems.add(new ResOrderFoodItem(2,"超值套餐"));
////        leftItems.add(new ResOrderFoodItem(3,"甜品"));
////        getFoodCatList();
//        leftItems=leftClassLists;
//
//        return leftItems;
//    }

    //获取菜式分类列表
    private void getFoodCatList(){

        if (!NetWorkState.isNetworkOpen(getActivity())){
            Toast.makeText(getActivity(),"请检查网络",Toast.LENGTH_LONG).show();
            return ;
        }else {
            new NetConnection(Config.GET_FOOD_CAT_URL, new HttpCallBackListener() {
                @Override
                public void onFinish(String response) {
                    try {
                        leftClassLists.clear();
                        JSONObject jsonRoot=new JSONObject(response);
                        String status=jsonRoot.getString("status");
                        if (status.equals("0")){
                            leftClassLists.add(new ResOrderFoodItem(0, "热门销售"));
                        }else if (status.equals("1")){
                            JSONArray json_data=jsonRoot.getJSONArray("data");

                            for (int i=0;i<json_data.length();i++){
                                JSONObject jsonObject=json_data.getJSONObject(i);
                                int classId=jsonObject.getInt("id");
                                String className=jsonObject.getString("name");
                                if (classId==0){
                                    leftClassLists.add(new ResOrderFoodItem(classId,className));
                                    break;
                                }else {
                                    String classImage=jsonObject.getString("image");
                                    ResOrderFoodItem item=new ResOrderFoodItem(classId,className,classImage);
                                    if (leftClassLists.size() < 1) {
                                        leftClassLists.add(item);
                                    }
                                    for (int m = 0; m < leftClassLists.size(); m++) {
                                        if (!(leftClassLists.get(m).getClassName().equals(className))) {
                                            leftClassLists.add(item);
                                            break;
                                        }
                                    }
                                }

                            }
                            isLoad=true;
                            adapter_left.notifyDataSetChanged();

//                            progressDialog.dismiss();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onError() {

                }
            },"rid",restaurantId);
        }
    }
    //获取菜式数据 ，并设置adapter
    private void getFoodList(){
        if (!NetWorkState.isNetworkOpen(getActivity())){
            Toast.makeText(getActivity(),"请检查网络",Toast.LENGTH_LONG).show();
            return ;
        }else {
            new NetConnection(Config.GET_FOOD_LIST_URL, new HttpCallBackListener() {
                @Override
                public void onFinish(String response) {
//                    System.out.println(response.toString());
                    try {
                        JSONObject json_root=new JSONObject(response);
                        String status=json_root.getString("status");
                        if (status.equals("1")){
                            JSONArray json_data=json_root.getJSONArray("data");

                            for (int i=0;i<json_data.length();i++){
                                JSONObject jsonObject=json_data.getJSONObject(i);
                                int id=jsonObject.getInt("id");
                                String name=jsonObject.getString("name");
                                String description=jsonObject.getString("description");
                                int restaurant_id=jsonObject.getInt("restaurant_id");
                                int classId=jsonObject.getInt("cat_id");
                                String prices=jsonObject.getString("prices");
                                int click_count=jsonObject.getInt("click_count");
                                String status2=jsonObject.getString("status");

                                ResOrderFoodItem resOrderFoodItem=new ResOrderFoodItem(
                                        id,name,description,restaurant_id,Float.valueOf(prices),
                                        click_count,status2,classId);
                                foodNetList.add(resOrderFoodItem);

                            }

                            ArrayList<ResOrderRightAdapter> rightItemList=new ArrayList<>();

                            for (int i=0;i<leftClassLists.size();i++){
                                ArrayList<ResOrderFoodItem> foodItems=new ArrayList<>();
                                for (int j=0;j<foodNetList.size();j++){
                                    ResOrderFoodItem item=foodNetList.get(j);
                                    if (foodNetList.get(j).getClassId()==leftClassLists.get(i).getClassId()){
                                        foodItems.add(item);
                                        System.out.println(item.getName());
                                    }
                                }
                                System.out.println(foodItems.size());

                                rightItemList.add(new ResOrderRightAdapter(getActivity(), foodItems, rootView));
                            }
                            listHeaderData = getListHeaderData();
//                            rightAdapterCount = getRightAdapterCount();
                            for (int i = 0; i < listHeaderData.size(); i++) {
                                sparated_adapter.addSection(listHeaderData.get(i), rightItemList.get(i));

                            }
                            sparated_adapter.notifyDataSetChanged();

                            progressDialog.dismiss();

                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

                @Override
                public void onError() {

                }
            },"rid",restaurantId);
        }
    }

}
