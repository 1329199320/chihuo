package com.sdpt.app.item;

/**
 * Created by Administrator on 2015/11/11.
 */
public class ContextOrderFoodItem  {

    private String id;
    private String order_id;
    private String user_id;
    private String food_id;
    private String restaurant_id;
    private int food_count;
    private String assess;
    private String assess_str;
    private String food;

//    public ContextOrderFoodItem(int id,int order_id,int user_id,
//                                int food_id,int restaurant_id,int food_count,
//                                String assess,String assess_str,String food)
    public ContextOrderFoodItem(String id,String order_id,String user_id,
                                String food_id,String restaurant_id,int food_count,
                                String assess,String assess_str,String food)
    {
        this.id=id;this.order_id=order_id;this.user_id=user_id;
        this.food_id=food_id;this.restaurant_id=restaurant_id;this.food_count=food_count;
        this.assess=assess;this.assess_str=assess_str;this.food=food;

    }

    //set

    public void setId(String id) {
        this.id = id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public void setFood_id(String food_id) {
        this.food_id = food_id;
    }

    public void setRestaurant_id(String restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public void setFood_count(int food_count) {
        this.food_count = food_count;
    }

    public void setAssess(String assess) {
        this.assess = assess;
    }

    public void setAssess_str(String assess_str) {
        this.assess_str = assess_str;
    }

    public void setFood(String food) {
        this.food = food;
    }


    //get


    public String getId() {
        return id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getFood_id() {
        return food_id;
    }

    public String getRestaurant_id() {
        return restaurant_id;
    }

    public int getFood_count() {
        return food_count;
    }

    public String getAssess() {
        return assess;
    }

    public String getAssess_str() {
        return assess_str;
    }

    public String getFood() {
        return food;
    }
}
