package com.sdpt.app.net;

/**
 * Created by Administrator on 2015/10/9.
 *
 * 此接口 为http请求的回调方法
 */
public interface HttpCallBackListener   {
    void onFinish(String response); //请求成功
    void onError(); //请求失败

}
