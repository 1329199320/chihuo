package com.sdpt.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.sdpt.app.R;
import com.sdpt.app.item.Restaurant;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/10.
 */
public class HomeItemAdapter extends BaseAdapter {

    private Context context;
//    private Cursor cursor;
    private ArrayList<Restaurant> list;

//    public HomeItemAdapter(Context context,Cursor cursor){
    public HomeItemAdapter(Context context,ArrayList<Restaurant> list){
        this.context=context;
        this.list=list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (convertView==null){
            convertView= LayoutInflater.from(context).inflate(R.layout.context_home_listview_item,null);
            viewHolder=new ViewHolder();

            viewHolder.photo= (ImageView) convertView.findViewById(R.id.image_Home_listItem_photo);
            viewHolder.name= (TextView) convertView.findViewById(R.id.text_home_listItem_name);
            viewHolder.ratingBar= (RatingBar) convertView.findViewById(R.id.ratingBar_home_listItem);

            convertView.setTag(viewHolder);
        }else {
            viewHolder= (ViewHolder) convertView.getTag();
        }
             viewHolder.name.setText(list.get(position).getName());
            viewHolder.ratingBar.setRating(list.get(position).getAssess());
            String path=list.get(position).getPhoto();
            Picasso.with(context).load(path).resize(100,80)
                .error(R.drawable.ic_action_error).into(viewHolder.photo);

        return convertView;
    }
    private class ViewHolder{
        ImageView photo;
        TextView name;
        RatingBar ratingBar;
    }


}
