package com.sdpt.app.item;

/**
 * Created by Administrator on 2015/11/11.
 */
public class ContextOrderUserInfoItem   {

    private String id;
    private String order_id; //订单id
    private String restaurant_id;//餐厅id
    private String order_price;//订单总价
    private String contact_name;//联系人姓名
    private String contact_sex;//联系人性别
    private String contact_phone;//联系人电话
    private String contact_address;//联系人地址
    private String order_status;//订单状态
    private String create_time;//订单创建时间
    private String restaurant;//餐厅名

    public ContextOrderUserInfoItem(String id,String order_id,String restaurant_id,
                                    String contact_name,String contact_sex,String contact_phone,
                                    String contact_address,String order_status,String create_time,
                                    String restaurant)
    {
      this.id=id;this.order_id=order_id;this.restaurant_id=restaurant_id;
        this.contact_name=contact_name;this.contact_sex=contact_sex;this.contact_phone=contact_phone;
        this.contact_address=contact_address;this.order_status=order_status;this.create_time=create_time;
        this.restaurant=restaurant;

    }
    public ContextOrderUserInfoItem(String id,String order_id,String restaurant_id,
                                    String contact_name,String contact_sex,String contact_phone,
                                    String contact_address,String order_status,String create_time,
                                    String restaurant,String order_price)
    {
        this.id=id;this.order_id=order_id;this.restaurant_id=restaurant_id;
        this.contact_name=contact_name;this.contact_sex=contact_sex;this.contact_phone=contact_phone;
        this.contact_address=contact_address;this.order_status=order_status;this.create_time=create_time;
        this.restaurant=restaurant;this.order_price=order_price;

    }

    public String toString(){
        return
                String.valueOf(getId())+","+String.valueOf(getOrder_id())+","+
                String.valueOf(getRestaurant_id())+","+getContact_name()+","+
                getContact_sex()+","+getContact_phone()+","+
                getContact_address()+","+getOrder_status()+","+
                getCreate_time()+","+getRestaurant();

    }


    //set方法

    public void setId(String id) {
        this.id = id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public void setRestaurant_id(String restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public void setContact_name(String contact_name) {
        this.contact_name = contact_name;
    }

    public void setContact_sex(String contact_sex) {
        this.contact_sex = contact_sex;
    }

    public void setContact_phone(String contact_phone) {
        this.contact_phone = contact_phone;
    }

    public void setContact_address(String contact_address) {
        this.contact_address = contact_address;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public void setRestaurant(String restaurant) {
        this.restaurant = restaurant;
    }

    public void setOrder_price(String order_price) {
        this.order_price = order_price;
    }
    //get方法


    public String getId() {
        return id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public String getRestaurant_id() {
        return restaurant_id;
    }

    public String getContact_name() {
        return contact_name;
    }

    public String getContact_sex() {
        return contact_sex;
    }

    public String getContact_phone() {
        return contact_phone;
    }

    public String getContact_address() {
        return contact_address;
    }

    public String getOrder_status() {
        return order_status;
    }

    public String getCreate_time() {
        return create_time;
    }

    public String getRestaurant() {
        return restaurant;
    }

    public String getOrder_price() {
        return order_price;
    }
}
