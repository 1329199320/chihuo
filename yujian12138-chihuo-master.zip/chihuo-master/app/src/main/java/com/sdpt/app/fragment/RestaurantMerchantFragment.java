package com.sdpt.app.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.squareup.picasso.Picasso;

/**
 * Created by Administrator on 2015/10/12.
 */
public class RestaurantMerchantFragment extends Fragment {
    private View rootView;
    //布局控件
    private RelativeLayout relative_background;//商家背景布局
    private ImageView image_phone,image_background;//电话图片,商家背景图片
    private TextView text_name,text_arriveTime;//商家名，到达时间
    private TextView text_atLeastPrice,text_deliveryPrice;//起送价，配送价
    private TextView text_serverTime,text_address;//服务时间，商家地址
    private TextView text_message;//信息
    private LinearLayout linear_message;//信息布局
    private RatingBar ratingBar;//评价



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView=inflater.inflate(R.layout.restaurant_merchant,container,false);

        init();
        initDate();
        initEvent();
        return rootView;
    }

    private void initDate(){
        //设置家名
        text_name.setText(getActivity().getIntent().getStringExtra(Config.RESTAURANT_NAME));
        //设置评价值
        int i= getActivity().getIntent().getIntExtra(Config.RESTAURANT_ASSESS, 0);
        ratingBar.setRating(i);
        //设置地址
        text_address.setText(getActivity().getIntent().getStringExtra(Config.RESTAURANT_ADDRESS));
        //设置背景
        setBackground();

    }

    private void initEvent(){
        //打电话
        final String photo="13124901190";
        image_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+photo));
                startActivity(intent);
            }
        });

    }

    private void setBackground(){
        DisplayMetrics dm = new DisplayMetrics();
        //获取屏幕信息
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenWidth = dm.widthPixels;
        //dp 转为像素
        float scale = getActivity().getResources().getDisplayMetrics().density;
        int height= (int) (120 * scale + 0.5f);

        Picasso.with(getActivity())
                .load(getActivity().getIntent().getStringExtra(Config.RESTAURANT_PHOTO))
//                .load("http://img5.imgtn.bdimg.com/it/u=2651666712,3423349209&fm=21&gp=0.jpg")
                .resize(screenWidth, height)
                .into(image_background);
    }

    //初始化控件
    private void init(){
        relative_background= (RelativeLayout) rootView.findViewById(R.id.relative_resMerchant_background);
        image_phone= (ImageView) rootView.findViewById(R.id.image_resMerchant_phone);
        text_name= (TextView) rootView.findViewById(R.id.text_resMerchant_name);
        text_arriveTime= (TextView) rootView.findViewById(R.id.text_resMerchant_Arrivetime);
        text_atLeastPrice= (TextView) rootView.findViewById(R.id.text_resMerchant_atLeastPrice);
        text_deliveryPrice= (TextView) rootView.findViewById(R.id.text_resMerchant_deliveryPrice);
        text_serverTime= (TextView) rootView.findViewById(R.id.text_resMerchant_serverTime);
        text_address= (TextView) rootView.findViewById(R.id.text_resMerchant_address);
        text_message= (TextView) rootView.findViewById(R.id.text_resMerchant_message);
        linear_message= (LinearLayout) rootView.findViewById(R.id.linear_resMerchant_message);
        ratingBar= (RatingBar) rootView.findViewById(R.id.ratingBar_resMerchant);
        image_background= (ImageView) rootView.findViewById(R.id.image_resMerchant_background);
    }

}
