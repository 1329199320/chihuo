package com.sdpt.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.sdpt.app.item.ResOrderSelectedFood;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Administrator on 2015/10/9.
 * 全局字段 ，变量
 */
public class Config {
    //url 地址
    public static final String SEVER_URL="http://dingcan.coding.io/api";  //服务器
    public static final String POST_REGISTER_URL ="http://dingcan.coding.io/Api/User/sign" ;//注册
    public static final String POST_LOGIN_URL ="http://dingcan.coding.io/Api/User/auth";//登录
    public static final String GET_FOOD_CAT_URL ="http://dingcan.coding.io/api/food/fetchFoodCatList";//获取菜式分类
//    public static final String SEVER_URL="http://kazamigakuen.oicp.net/Api";
    public static final String GET_FOOD_LIST_URL ="http://dingcan.coding.io/api/Food/fetchList"; //获取菜式详细信息
    public static final String POST_SUBMIT_URL ="http://dingcan.coding.io/api/order/orderSubmit" ;//提交订单
    public static final String GET_ORDER_LIST_URL="http://dingcan.coding.io/api/order/fetchList";//获取用户订单
    public static final String CHARSET="utf-8";

    public static final String FILE_DIR_APP ="chihuo" ; //程序文件夹

    public static final String SHARE_HOME="shareHome";
    public static final String SHARE_HOME_ISFIRST_LOAD="isFirstLoad";

    public static final String DB_NAME="chihuo"; //数据库名
    public static final int  DB_VERSION=1;  //数据库版本

    //RestaurantOrderFragment 菜单栏的商品状态
    public static final String FOOD_STATE_NORMAL="1";
    public static final String FOOD_STATE_ORDERING="2";
    public static final String FOOD_STATE_REST="3";

    //Restaurant表的字段
    public static final String TABLE_RESTAURANT ="Restaurant" ;
    public static final String RESTAURANT_ID ="id";
    public static final String RESTAURANT_NAME ="name" ;
    public static final String RESTAURANT_PHOTO ="photo" ;
    public static final String RESTAURANT_DESCRIPTION ="description";
    public static final String RESTAURANT_ADDRESS ="address" ;
    public static final String RESTAURANT_STATUS ="status" ;
    public static final String RESTAURANT_PREFERENTIAL ="preferential";
    public static final String RESTAURANT_ASSESS ="assess";

    //Assess表的字段
    public static final String TABLE_ASSESS="assess";
    public static final String ASSESS_ID="id";
    public static final String ASSESS_USER_ID="userId";
    public static final String ASSESS_RESTAURANT_ID="restaurantId";
    public static final String ASSESS_USER_NAME="userName";
    public static final String ASSESS_USER_PIC="userPic";
    public static final String ASSESS__TIME="userAssessTime";
    public static final String ASSESS_RATING="rating";
    public static final String ASSESS_COMMENT="comment";

    //提交用户信息
    public static final String POST_USER_NAME ="username";
    public static final String POST_USER_PASSWORD ="password" ;

    public static final String  APP_ID="com.sdpt.app";
    public static final String KEY_TOKEN="token";
    public static final String USER_ID ="userID" ;
    public static final String USER_NAME ="username" ;
    public static final String JSON_USER_ID ="userID" ;
    public static final String JSON_RESTAURANT_ID ="restaurantID" ;


    //收货地址表信息
    public static String TABLE_ADDRESS="address";
    public static String ADDRESS_ID="id";
    public static String ADDRESS_CONTACT_NAME="contactName";
    public static String ADDRESS_SEX="sex";
    public static String ADDRESS_PHONE="phone";
    public static String ADDRESS_ADDRESS="address";
    public static String ADDRESS_ADDRESS_DETAIL="addressDetail";
    public static String ADDRESS_UPDATE_TIME="updateTime";

    //菜式表的信息
    public static String TABLE_ORDER="order";
    public static String ORDER_ID="id";
    public static String ORDER_NAME="name";
    public static String ORDER_CLASS_NAME="className";
    public static String ORDER_CLASS_URL="classUrl";
    public static String ORDER_CLASS_ID="classId";
    public static String ORDER_IMAGE_URL="imageUrl";
    public static String ORDER_DESCRIPTION="description";
    public static String ORDER_RESTAURANT_ID="restaurant_id";
    public static String ORDER_PRICES="prices";
    public static String ORDER_CLICK_COUNT="click_count";
    public static String ORDER_STATUS="status";


    public static void cacheToken(Context context,String token){
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_TOKEN, token);
        e.commit();
    }
    public static String getCachedToken(Context context){
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_TOKEN, null);
    }

    public static ArrayList<ResOrderSelectedFood> selectedFoods=new ArrayList<ResOrderSelectedFood>();
    public static int totalSelectedPrice=0;
    public static int totalSelectedCount=0;

    //用户选择菜单的信息 根据餐厅id
    public static HashMap<String,ArrayList<ResOrderSelectedFood>> listSelectedFoods=new HashMap<String,ArrayList<ResOrderSelectedFood>>();
    public static HashMap<String,Float> listSelectedPrice =new HashMap<>();
    public static HashMap<String,Integer> listSelectedCount=new HashMap<>();

}
