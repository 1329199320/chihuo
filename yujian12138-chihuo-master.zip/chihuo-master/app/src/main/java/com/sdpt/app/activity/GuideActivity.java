package com.sdpt.app.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.sdpt.app.R;
import com.sdpt.app.adapter.ViewPageAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2015/10/4.
 *
 *  GuideActivity 为引导欢迎页
 */
public class GuideActivity extends Activity implements ViewPager.OnPageChangeListener{

    private ViewPageAdapter pageAdapter;
    private List<View> viewList;
    private ViewPager viewPager;
    private ImageView[] imagePoints; //点的集合  当引导页被选择，点的状态会做相应改变
    private int[] pointsId={R.id.image_guide_1,R.id.image_guide_2,R.id.image_guide_3};  //点Id 的集合
    private Button btn_guide_start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        initView();  //初始化页面
        initPoints(); //初始化点
    }
    private void initView(){
        LayoutInflater inflater=LayoutInflater.from(this);
        viewList=new ArrayList<View>();

        viewList.add(inflater.inflate(R.layout.activity_guide_one,null)); // 初始化第一个引导页
        viewList.add(inflater.inflate(R.layout.activity_guide_two,null));
        viewList.add(inflater.inflate(R.layout.activity_guide_three,null));

        viewPager= (ViewPager)findViewById(R.id.viewPage_guide);
        pageAdapter=new ViewPageAdapter(this,viewList);
        viewPager.setAdapter(pageAdapter);
        viewPager.setOnPageChangeListener(this);

        btn_guide_start= (Button)viewList.get(2).findViewById(R.id.btn_guide_start);
        btn_guide_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goContext();
            }
        });

    }
    //初始化点
    private void initPoints(){
        imagePoints=new ImageView[viewList.size()];
        for (int i=0;i<viewList.size();i++){
            imagePoints[i]=(ImageView)findViewById(pointsId[i]);
        }
    }
    private void goContext(){
        startActivity(new Intent(this,ContextMainActivity.class));
        finish();
    }


    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    //当引导页选择时，点的状态的改变
    @Override
    public void onPageSelected(int position) {
        for (int i=0;i<pointsId.length;i++){
            if (position==i){
                imagePoints[i].setImageResource(R.drawable.login_point_selected);
            }else {
                imagePoints[i].setImageResource(R.drawable.login_point);
            }
        }
    }

    @Override
     public void onPageScrollStateChanged(int state) {
    }


}
