package com.sdpt.app.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.db.MainDB;
import com.sdpt.app.fragment.RestaurantCommentFragment;
import com.sdpt.app.fragment.RestaurantMerchantFragment;
import com.sdpt.app.fragment.RestaurantOrderFragment;
import com.sdpt.app.item.ResOrderSelectedFood;

import java.util.ArrayList;
import java.util.Locale;

/*
* 商家详情主Activity
* */

public class RestaurantActivity extends ActionBarActivity implements ActionBar.TabListener {

    SectionsPagerAdapter mSectionsPagerAdapter;
    ViewPager mViewPager;
    private   String restaurant_name=null;
    public static String restaurant_id="";
    private MainDB mainDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        // Set up the action bar.
        final ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

//        restaurant_id=getIntent().getIntExtra(Config.RESTAURANT_ID, 0);
        restaurant_name=getIntent().getStringExtra(Config.RESTAURANT_NAME);
        restaurant_id=getIntent().getStringExtra(Config.RESTAURANT_ID);

        actionBar.setTitle(restaurant_name);
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        //添加选中项
        System.out.println("{{{{{{{{{{{{" + restaurant_id);

        if (!Config.listSelectedFoods.containsKey(restaurant_id)){
            Config.listSelectedFoods.put(restaurant_id,new ArrayList<ResOrderSelectedFood>());
        }
        if (!Config.listSelectedCount.containsKey(restaurant_id)){
            Config.listSelectedCount.put(restaurant_id, 0);
        }
        if (!Config.listSelectedPrice.containsKey(restaurant_id)){
            Config.listSelectedPrice.put(restaurant_id, 0f);
        }

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        mViewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);

            }
        });
        for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
            actionBar.addTab(
                    actionBar.newTab()
                            .setText(mSectionsPagerAdapter.getPageTitle(i))
                            .setTabListener(this));
        }

    }

    //当activity停止时，清空Config.selectedFoods的数据
    @Override
    protected void onPause() {
        super.onPause();
//        System.out.println("+++++++++++++");
//        Config.totalSelectedCount=0;
//        Config.totalSelectedPrice=0;
//        if (Config.selectedFoods.size()>0) {
//            for (int i = 0; i < Config.selectedFoods.size(); i++) {
//                Config.selectedFoods.get(i).setCount(0);
//                Config.selectedFoods.remove(i);
//            }
//            Config.selectedFoods.clear();
//        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_restaurant, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
        mViewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }
        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
//            return PlaceholderFragment.newInstance(position + 1);
            switch (position){
                case 0:
                    return new RestaurantOrderFragment();
                case 1:
                    return new RestaurantCommentFragment();
                case 2:
                    return new RestaurantMerchantFragment();
            }
            return null;
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            Locale l = Locale.getDefault();
            switch (position) {
                case 0:
                    return getString(R.string.title_order).toUpperCase();
                case 1:
                    return getString(R.string.title_comment).toUpperCase(l);
                case 2:
                    return getString(R.string.title_merchant).toUpperCase(l);
            }
            return null;
        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_restaurant, container, false);
            return rootView;
        }
    }

}
