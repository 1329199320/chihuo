package com.sdpt.app;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.sdpt.app.activity.WelcomeActivity;

/*
*  MainActivity 不做任何页面显示 仅为跳转页面
*  程序启动时 跳转为WelcomeActivity
*  注：写代码时可改为其它 Activity
*  */

public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        SDKInitializer.initialize(getApplicationContext());
//        setContentView(R.layout.activity_main);

//        startActivity(new Intent(MainActivity.this, HttpTest.class));
//        startActivity(new Intent(MainActivity.this,ContextMainActivity.class));
        startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
        finish();
    }
}
