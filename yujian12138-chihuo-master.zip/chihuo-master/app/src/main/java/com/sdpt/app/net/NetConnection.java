package com.sdpt.app.net;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by Administrator on 2015/10/9.
 *
 * NetConnection 为网络连接类,网络请求方式为 GET 方式。
 *  @param String SeverAddress 服务器地址。
 * @param HttpCallBackListener listener 网络请求回调接口，
 *        需实现 OnFinish(String result),OnError()两个方法。
 * @param String... kvs 需要存入的参数。
 */
public class NetConnection {
    public NetConnection(final String serverAddress, final HttpCallBackListener listener, final String... kvs){
        new AsyncTask<Void,Void,String>(){
            @Override
            protected String doInBackground(Void... voids) {
                //将参数集合以 " ../../.." 的形式传给服务器
                StringBuilder paramStr=new StringBuilder();
                for (int i=0;i<kvs.length;i++){
                    paramStr.append("/").append(kvs[i]);
                }
                String urlStr=serverAddress+paramStr.toString();
                URLConnection urlConnection;
                try {
                    URL url=new URL(urlStr);
                    urlConnection=url.openConnection();
                    InputStream input =urlConnection.getInputStream();
                    BufferedReader reader=new BufferedReader(new InputStreamReader(input));
                    StringBuilder result=new StringBuilder();
                    String line=null;
                    while ((line=reader.readLine())!=null){
                        result.append(line);
                    }
                    return result.toString();
                } catch (MalformedURLException e) {
                    e.printStackTrace();

                } catch (IOException e) {
                    e.printStackTrace();

                }

                return null;
            }
            /*
            * @param String result 服务器返回的结果
            */
            @Override
            protected void onPostExecute(String result) {
                if (result!=null){
                    if (listener!=null){
                        listener.onFinish(result); //把结果传给实现的类
                    }
                }else {
                    if (listener!=null){
                        listener.onError();
                    }
                }
                super.onPostExecute(result);
            }
        }.execute();

    }
}
