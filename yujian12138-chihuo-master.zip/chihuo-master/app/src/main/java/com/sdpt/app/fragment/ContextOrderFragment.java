package com.sdpt.app.fragment;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.activity.ContextOrderDetailActivity;
import com.sdpt.app.activity.MyLoginActivity;
import com.sdpt.app.adapter.ContextOrderAdapter;
import com.sdpt.app.item.ContextOrderFoodItem;
import com.sdpt.app.item.ContextOrderUserInfoItem;
import com.sdpt.app.item.UserAssessItem;
import com.sdpt.app.net.HttpCallBackListener;
import com.sdpt.app.net.NetConnection;
import com.sdpt.app.net.NetWorkState;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by Administrator on 2015/10/6.
 */
public class ContextOrderFragment extends Fragment implements View.OnClickListener{

    private View rootView;
    private Context context;
    private String userId="";
    private static int REQUEST_TO_LOGIN=0;
    //根据不同值显示不同状态页面  无网络 0， 没登录 1，正常 2 没有信息 3
    private static  int UI_STATUS=2; //状态
    private static final int UI_STATUS_NETWORK=0; //无网络
    private static final int UI_STATUS_IS_LOGIN=1;//没登录
    private static final int UI_STATUS_NORMAL=2;//正常
    private static final int UI_STATUS_NO_INFO=3;//没有信息

    private boolean isHaveInfo=true;

    //初始化布局
    private ListView listView;
    private TextView textView_isLogin;
    private TextView textView_network;
    private TextView textView_noInfo;

    //用户订单的用户信息
    public static ArrayList<ContextOrderUserInfoItem> userItems=new ArrayList<>();
//    public static HashMap<String,ContextOrderUserInfoItem> userItems=new HashMap<>();
    //用户订单的菜式信息
    public static HashMap<String,ArrayList<ContextOrderFoodItem>> foodMap=
            new HashMap<String,ArrayList<ContextOrderFoodItem>>();

    ContextOrderAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView=inflater.inflate(R.layout.context_order, container, false);

        context=getActivity();
        initView();
        checkNetworkAndLogin();
        getNetData();
        listEvent();
        return rootView;
    }
    private void initView(){
        listView= (ListView) rootView.findViewById(R.id.listView_contextOrder);
        textView_isLogin= (TextView) rootView.findViewById(R.id.text_contextOrder_isLogin);
        textView_network= (TextView) rootView.findViewById(R.id.text_contextOrder_network);
        textView_noInfo= (TextView) rootView.findViewById(R.id.text_contextOrder_noOrderInfo);
        textView_isLogin.setOnClickListener(this);

        adapter=new ContextOrderAdapter(getActivity(),userItems);
        listView.setAdapter(adapter);
    }
    private void listEvent(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent=new Intent(getActivity(), ContextOrderDetailActivity.class);
                intent.putExtra("order_id", userItems.get(i).getOrder_id());
                startActivity(intent);
            }
        });
    }

    private void handleListView(){
        if (userItems.size()<1){
            return;
        }else {
        }
    }

    //判断显示
    private void checkNetworkAndLogin(){
        if (!NetWorkState.isNetworkOpen(getActivity())){
            UI_STATUS=UI_STATUS_NETWORK;
        }else if (!isLogin()){
            UI_STATUS=UI_STATUS_IS_LOGIN;
        }else if (!isHaveInfo){
            UI_STATUS=UI_STATUS_NO_INFO;
        }else {
            UI_STATUS=UI_STATUS_NORMAL;
        }
        changeStatus(UI_STATUS);
    }
    //根据不同值显示不同状态页面  无网络 0， 没登录 1，正常 2 没有信息 3
    private void changeStatus(int i){
        switch (i){
            case UI_STATUS_NETWORK:
                textView_network.setVisibility(View.VISIBLE);
                textView_isLogin.setVisibility(View.GONE);
                listView.setVisibility(View.GONE);
                textView_noInfo.setVisibility(View.GONE);
                break;
            case UI_STATUS_IS_LOGIN:
                textView_network.setVisibility(View.GONE);
                textView_isLogin.setVisibility(View.VISIBLE);
                listView.setVisibility(View.GONE);
                textView_noInfo.setVisibility(View.GONE);
                break;
            case UI_STATUS_NORMAL:
                textView_network.setVisibility(View.GONE);
                textView_isLogin.setVisibility(View.GONE);
                listView.setVisibility(View.VISIBLE);
                textView_noInfo.setVisibility(View.GONE);
                break;
            case UI_STATUS_NO_INFO:
                textView_network.setVisibility(View.GONE);
                textView_isLogin.setVisibility(View.GONE);
                listView.setVisibility(View.GONE);
                textView_noInfo.setVisibility(View.VISIBLE);
                break;
        }
    }
    //是否已经登录
    private boolean isLogin(){
        SharedPreferences sharedPreferences=context.getSharedPreferences(Config.APP_ID,Context.MODE_PRIVATE);
        userId=sharedPreferences.getString(Config.USER_ID,"");
        if (TextUtils.isEmpty(userId)){
            return false;
        }
        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
        checkNetworkAndLogin();
    }

    private void getNetData(){
        if (TextUtils.isEmpty(userId)){
            return;
        }
        new NetConnection(Config.GET_ORDER_LIST_URL, new HttpCallBackListener() {
            @Override
            public void onFinish(String response) {
                handleResponseData(response);
            }
            @Override
            public void onError() {

            }
        },"uid",userId);
    }
    //处理接收的数据
    private void handleResponseData(String response){
        if (response.length()<5){
            isHaveInfo=false;
            checkNetworkAndLogin();
            return;
        }
        try {
            JSONArray jsonRoot=new JSONArray(response);
//            System.out.println("<<"+jsonRoot.toString());
            ContextOrderUserInfoItem userItem;
            foodMap.clear();
            ArrayList<ContextOrderFoodItem> foodItems;
            userItems.clear();
            for (int i=0;i<jsonRoot.length();i++){
                JSONObject jsonObject=jsonRoot.getJSONObject(i);
                //消费者的信息
                userItem=new ContextOrderUserInfoItem(jsonObject.getString("id"), jsonObject.getString("order_id"),
                        jsonObject.getString("restaurant_id"), jsonObject.getString("contact_name"),
                        jsonObject.getString("contact_sex"), jsonObject.getString("contact_phone"),
                        jsonObject.getString("contact_address"), jsonObject.getString("order_status"),
                        jsonObject.getString("create_time"), jsonObject.getString("restaurant"),
                        jsonObject.getString("order_price"));
                userItems.add(userItem);
                //下单详细

                JSONArray json_detail=jsonObject.getJSONArray("order_detail");
                foodItems=new ArrayList<>();
                ContextOrderFoodItem foodItem;
                for (int j=0;j<json_detail.length();j++){
                    JSONObject jsonObject1=json_detail.getJSONObject(j);
                    foodItem=new ContextOrderFoodItem(jsonObject1.getString("id"),jsonObject1.getString("order_id"),
                            jsonObject1.getString("user_id"),jsonObject1.getString("food_id"),
                            jsonObject1.getString("restaurant_id"),jsonObject1.getInt("food_count"),
                            jsonObject1.getString("assess"),jsonObject1.getString("assess_str"),
                            jsonObject1.getString("food"));
                    foodItems.add(foodItem);
                }
                foodMap.put(userItem.getOrder_id(),foodItems);


            }
            Collections.sort(userItems,new TimeCompare());
            adapter.notifyDataSetChanged();
            for (Map.Entry<String,ArrayList<ContextOrderFoodItem>> entry:foodMap.entrySet()){
                System.out.println(entry.getKey()+",,,");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.text_contextOrder_isLogin:
                startActivityForResult(new Intent(getActivity(), MyLoginActivity.class),REQUEST_TO_LOGIN);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==REQUEST_TO_LOGIN){
            userId=data.getStringExtra(Config.USER_ID);
            checkNetworkAndLogin();
        }
    }

    //时间比较
    class TimeCompare implements Comparator<ContextOrderUserInfoItem> {

        @Override
        public int compare(ContextOrderUserInfoItem t1, ContextOrderUserInfoItem t2) {
            DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            try {
                Date date1=dateFormat.parse(t1.getCreate_time());
                Date date2=dateFormat.parse(t2.getCreate_time());
                if (date1.getTime()>date2.getTime()){
                    return -1;
                }
                if (date1.getTime()<date2.getTime()){
                    return 1;
                }
                else
                    return 0;
            } catch (ParseException e) {
                e.printStackTrace();
            }

            return 0;

        }

    }
}
