package com.sdpt.app.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

import com.sdpt.app.R;
import com.sdpt.app.net.NetWorkState;


/**
 * Created by Administrator on 2015/10/4.
 *
 *  WelcomeActivity 为欢迎页面。
 *  首次安装程序时，会进入引导页 GuideActivity，
 *  其它情况则进入 主页 ContextMainActivity。
 */
public class WelcomeActivity extends Activity {
    private boolean isFistIn=false; // isFistIn 判断是否是 首次 运行程序
    private static final int TIME=2000; // 跳转时间间隔
    private static final int GO_CONTEXT=1005;
    private static final int GO_GUIDE=1000;

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case GO_CONTEXT:
                    goContext();
                    break;
                case GO_GUIDE:
                    goGuide();
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        if (NetWorkState.isNetworkOpen(WelcomeActivity.this)==false)
        {
            Toast.makeText(getApplicationContext(), "当前没有可用网络！", Toast.LENGTH_LONG).show();
        }
        init();
    }

    private void init(){
        SharedPreferences sharedPreferences=getSharedPreferences("chiHuo", MODE_PRIVATE);
        isFistIn=sharedPreferences.getBoolean("isFistIn",true);
        if (!isFistIn){
            handler.sendEmptyMessageDelayed(GO_CONTEXT,TIME);
        }else {
            handler.sendEmptyMessageDelayed(GO_GUIDE,TIME);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putBoolean("isFistIn",false);
            editor.commit();
        }
    }
    /*
    * 跳转到ContextMainActivity
    * */
    private void goContext(){
        Intent intentGoContext=new Intent(WelcomeActivity.this,ContextMainActivity.class);
        startActivity(intentGoContext);
        finish();
    }

    /*
    * 跳转到GuideActivity
    * */
    private void goGuide(){
        Intent intentGoGuide=new Intent(WelcomeActivity.this,GuideActivity.class);
        startActivity(intentGoGuide);
        finish();
    }
}
