package com.sdpt.app.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.item.ResOrderFoodItem;
import com.sdpt.app.item.ResOrderSelectedFood;
import com.sdpt.app.model.ResOrderFooterView;
import com.sdpt.app.activity.RestaurantActivity;
import com.sdpt.app.activity.SubmitOrderActivity;
import com.sdpt.app.util.ResOrderSelectedFoodCompare;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Administrator on 2015/10/17.
 *
 */
public class ResOrderRightAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<ResOrderFoodItem> list;
    private ResOrderFoodItem resOrderFoodItem;
    private ScaleAnimation scaleAnimationUp;
    private ScaleAnimation scaleAnimationDown;
    private FooterView footerView;//RestaurantOrder的尾部布局view
    private View rootView;//整个ResOrder布局

    private ResOrderFooterView twoFooterView;
    private TwoFooterClass twoFooterClass;
    private View halfView;
    private View twoFooterItemView;
    private  First_ViewHolder first_viewHolder;
    private String restatuantId;

    public ResOrderRightAdapter(Context context, ArrayList<ResOrderFoodItem> list, View rootView) {
        this.context = context;
        this.list = list;
        this.rootView = rootView;
        footerView = new FooterView();
        restatuantId=RestaurantActivity.restaurant_id;
        twoFooterView = (ResOrderFooterView) rootView.findViewById(R.id.resOrder_modelFooterView);
        halfView = rootView.findViewById(R.id.view_resOrder);
        twoFooterClass = new TwoFooterClass();
        checkState();
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {

        resOrderFoodItem = list.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.resturant_order_right_item, null);
            first_viewHolder = new First_ViewHolder();
            first_viewHolder.image_pic= (ImageView) convertView.findViewById(R.id.image_resOrder_rightItem_pic);
            first_viewHolder.text_name = (TextView) convertView.findViewById(R.id.text_resOrder_rightItem_name);
//            viewHolder.text_sales= (TextView) convertView.findViewById(R.id.text_resOrder_rightItem_sales);
//            viewHolder.text_good= (TextView) convertView.findViewById(R.id.text_resOrder_rightItem_good);
            first_viewHolder.text_price = (TextView) convertView.findViewById(R.id.text_resOrder_rightItem_price);
//            viewHolder.linearLayout_select= (LinearLayout) convertView.findViewById(R.id.linearLayout_resOrder_rightItem_select);
            first_viewHolder.linearLayout_remove = (LinearLayout) convertView.findViewById(R.id.linearLayout_ResOrder_RightItem_remove);
            first_viewHolder.image_remove = (ImageView) convertView.findViewById(R.id.image_resOrder_rightItem_remove);
            first_viewHolder.text_count = (TextView) convertView.findViewById(R.id.text_resOrder_rightItem_count);
            first_viewHolder.image_add = (ImageView) convertView.findViewById(R.id.image_resOrder_rightItem_add);
            first_viewHolder.text_rest = (TextView) convertView.findViewById(R.id.text_resOrder_rightItem_rest);

            convertView.setTag(first_viewHolder);
        } else {
            first_viewHolder = (First_ViewHolder) convertView.getTag();
        }
        if (TextUtils.isEmpty(resOrderFoodItem.getImageUrl())){
            first_viewHolder.image_pic.setVisibility(View.GONE);
        }else {
            first_viewHolder.image_pic.setVisibility(View.VISIBLE);
            Picasso.with(context)
                    .load(resOrderFoodItem.getImageUrl()).into(first_viewHolder.image_pic);
        }

        first_viewHolder.text_name.setText(resOrderFoodItem.getName());
        first_viewHolder.text_price.setText(String.valueOf(resOrderFoodItem.getPrices()));

        if (Config.listSelectedCount.get(restatuantId)<1){
            first_viewHolder.linearLayout_remove.setVisibility(View.GONE);
            first_viewHolder.text_count.setText("0");
        }
        else {
            for (int m=0;m<Config.listSelectedFoods.get(restatuantId).size();m++){
                if (resOrderFoodItem.getId()!=Config.listSelectedFoods.get(restatuantId).get(m).getId()){
                    first_viewHolder.linearLayout_remove.setVisibility(View.GONE);
                }else {
                    if (Config.listSelectedFoods.get(restatuantId).get(m).getCount()>0){
                      first_viewHolder.text_count.setText(String.valueOf(Config.listSelectedFoods.get(restatuantId).get(m).getCount()));
                      first_viewHolder.linearLayout_remove.setVisibility(View.VISIBLE);
                        break;
                    }
                }
            }
        }

        checkState();
        initEvent(first_viewHolder, resOrderFoodItem);

        return convertView;
    }

    private void initEvent(final First_ViewHolder viewHolder, final ResOrderFoodItem resOrderFoodItem) {

        viewHolder.image_add.setOnClickListener(new View.OnClickListener() {
            int count = 0;

            @Override
            public void onClick(View view) {
                count = Integer.valueOf(viewHolder.text_count.getText().toString());
                if (count <= 0) {
                    count = 0;
                    scaleAnimationUp = new ScaleAnimation(0.1f, 1f, 0.1f, 1f, Animation.RELATIVE_TO_SELF, 1f,
                            Animation.RELATIVE_TO_SELF, 0.5f);
                    scaleAnimationUp.setDuration(300);
                    viewHolder.linearLayout_remove.setAnimation(scaleAnimationUp);
                }
                viewHolder.linearLayout_remove.setVisibility(View.VISIBLE);

                count += 1; //单个菜的数目
                int tempCount = Config.listSelectedCount.get(restatuantId);
                Config.listSelectedCount.put(restatuantId, tempCount + 1);//菜的总共数目
                float tempPrice = Config.listSelectedPrice.get(restatuantId);
                Config.listSelectedPrice.put(restatuantId, +tempPrice + resOrderFoodItem.getPrices());//总共的价格
                viewHolder.text_count.setText(String.valueOf(count));
//                ---------------------------------------------
                //用户已选择列表
                if (Config.listSelectedFoods.get(restatuantId).size() == 0) {
                    Config.listSelectedFoods.get(restatuantId).add(new ResOrderSelectedFood(resOrderFoodItem.getId(),
                            resOrderFoodItem.getName(), 1, resOrderFoodItem.getPrices()));
                } else {
                    boolean isSelectedFood = false;
                    for (int i = 0; i < Config.listSelectedFoods.get(restatuantId).size(); i++) {
                        if (resOrderFoodItem.getName() == Config.listSelectedFoods.get(restatuantId).get(i).getName()) {
                            Config.listSelectedFoods.get(restatuantId).get(i).setCount(
                                    Config.listSelectedFoods.get(restatuantId).get(i).getCount() + 1
                            );
                            isSelectedFood = true;
                            break;
                        }
                    }
                    if (!isSelectedFood) {
                        Config.listSelectedFoods.get(restatuantId).add(new ResOrderSelectedFood(resOrderFoodItem.getId(), resOrderFoodItem.getName(),
                                1, resOrderFoodItem.getPrices()));
                    }

                }
                //footed的响应
                checkState();
                for (int n = 0; n < Config.listSelectedFoods.get(restatuantId).size(); n++) {
                    System.out.println("++++++++++" + Config.listSelectedFoods.get(restatuantId).get(n).getName());
                }


            }
        });

        viewHolder.image_remove.setOnClickListener(new View.OnClickListener() {
            int count;

            @Override
            public void onClick(View view) {
                Config.listSelectedCount.put(restatuantId,Config.listSelectedCount.get(restatuantId)-1); //选择菜的总数
                count = Integer.valueOf(viewHolder.text_count.getText().toString());
                count -= 1;//单个菜的数目
                Config.listSelectedPrice.put(restatuantId,Config.listSelectedPrice.get(restatuantId)-resOrderFoodItem.getPrices());//总共的价格

                if (count < 1) {
                    viewHolder.linearLayout_remove.setVisibility(View.GONE);
                }
                viewHolder.text_count.setText(String.valueOf(count));

                //用户选择列表
                for (int i = 0; i < Config.listSelectedFoods.get(restatuantId).size(); i++) {
                    if (resOrderFoodItem.getName() == Config.listSelectedFoods.get(restatuantId).get(i).getName()) {
                        Config.listSelectedFoods.get(restatuantId).get(i)
                                .setCount(Config.listSelectedFoods.get(restatuantId).get(i).getCount() - 1);
                        break;
                    }

                }
                for (int n = 0; n < Config.listSelectedFoods.get(restatuantId).size(); n++) {
                    if (Config.listSelectedFoods.get(restatuantId).get(n).getCount() == 0) {
                        Config.listSelectedFoods.get(restatuantId).remove(n);
                        break;
                    }
                }

                //footer
                checkState();

            }
        });
        footerEvent();
        twoFooterEvent();
    }

    private void footerEvent() {

        twoFooterView.setEnabled(true);

        //点击第一个购物车
        footerView.image_cart.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (Config.listSelectedCount.get(restatuantId) < 1) {

                } else {
                    if (twoFooterView.isShow) {
                        footerView.relative_footer.setVisibility(View.VISIBLE);
                        halfView.setVisibility(View.GONE);
                        twoFooterView.dismiss();
                    } else {

                        ListView listView= (ListView) twoFooterView.findViewById(R.id.listView_resOrder_twoFooter);

                        TwoFooterAdapter twoFooterAdapter=new TwoFooterAdapter();
                        listView.setAdapter(twoFooterAdapter);

                        footerView.relative_footer.setVisibility(View.GONE);
                        halfView.setVisibility(View.VISIBLE);
                        twoFooterView.show();
                    }
                }

            }
        });
        //设置半透明背景
        halfView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (twoFooterView.isShow) {
                    twoFooterView.dismiss();
                    halfView.setVisibility(View.GONE);
                    footerView.relative_footer.setVisibility(View.VISIBLE);
                }
            }
        });


        footerView.btn_selected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Config.listSelectedCount.get(restatuantId)>0){
                    submitOrder();
                }
            }
        });


    }

    private void submitOrder(){
        Intent intent=new Intent(rootView.getContext(),SubmitOrderActivity.class);
        intent.putExtra(Config.RESTAURANT_ID,restatuantId);
        context.startActivity(intent);
    }


    private void twoFooterEvent() {
        twoFooterClass.text_twoFooter_totalCount.setText(String.valueOf(Config.listSelectedCount.get(restatuantId)));
        twoFooterClass.text_twoFooter_totalPrice.setText("￥" + Float.valueOf(Config.listSelectedPrice.get(restatuantId)));

        //购物车点击时
        twoFooterView.setEnabled(true);
        twoFooterClass.image_twoFooter_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (twoFooterView.isShow) {
                    footerView.relative_footer.setVisibility(View.VISIBLE);
                    halfView.setVisibility(View.GONE);
                    twoFooterView.dismiss();
                }
            }
        });

        //清空购物车
        twoFooterClass.image_twoFooter_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whenNoSelected();
            }
        });

        twoFooterClass.btn_twoFooter_selected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitOrder();
            }
        });

    }

    private void whenNoSelected(){
        for (int i=0;i<Config.listSelectedFoods.get(restatuantId).size();i++){
            Config.listSelectedFoods.get(restatuantId).get(i).setCount(0);
            Config.listSelectedFoods.get(restatuantId).remove(i);
        }
        Config.listSelectedFoods.get(restatuantId).clear();
        Config.listSelectedCount.put(restatuantId,0);
        Config.listSelectedPrice.put(restatuantId,0f);
        checkState();
        if (twoFooterView.isShow){
            footerView.relative_footer.setVisibility(View.VISIBLE);
            halfView.setVisibility(View.GONE);
            twoFooterView.dismiss();
        }
    }
    private void changeData(){
        if (Config.listSelectedFoods.get(restatuantId).size()<1||Config.listSelectedCount.get(restatuantId)==0){
            whenNoSelected();
        }else {
            twoFooterClass.text_twoFooter_totalCount.setText(String.valueOf(Config.listSelectedCount.get(restatuantId)));
            twoFooterClass.text_twoFooter_totalPrice.setText("￥"+String.valueOf(Float.valueOf(Config.listSelectedPrice.get(restatuantId))));
            footerView.text_count.setText(String.valueOf(Config.listSelectedCount.get(restatuantId)));
            footerView.text_price.setText(String.valueOf(Float.valueOf(Config.listSelectedPrice.get(restatuantId))));
        }
    }

    private void checkState() {

        //判断用户选择时，footer布局进行调整.
        if (Config.listSelectedCount.get(restatuantId) < 1) {
            footerView.image_cart.setBackgroundResource(R.drawable.ic_add_shopping_cart_black_36dp);
            footerView.text_noPrice.setVisibility(View.VISIBLE);
            footerView.linear_price.setVisibility(View.GONE);
            footerView.text_count.setVisibility(View.GONE);

            //设置点击按钮
            footerView.btn_selected.setBackgroundColor(
                    context.getResources().getColor(R.color.button_background_black));
            footerView.btn_selected.setText("请选择");

        } else //用户选择时显示
        {
            footerView.image_cart.setBackgroundResource(R.drawable.ic_add_shopping_cart_white__36dp);
            footerView.text_noPrice.setVisibility(View.GONE);
            footerView.linear_price.setVisibility(View.VISIBLE);
            footerView.text_count.setVisibility(View.VISIBLE);
            footerView.text_count.setText(String.valueOf(Config.listSelectedCount.get(restatuantId)));
            footerView.text_price.setText(String.valueOf(Float.valueOf(Config.listSelectedPrice.get(restatuantId))));

            //设置点击按钮
            footerView.btn_selected.setBackgroundColor(
                    context.getResources().getColor(R.color.button_background_light));
            footerView.btn_selected.setText("结算");

        }
    }

    //底部布局的初始化
    class FooterView {
        ImageView image_cart = (ImageView) rootView.findViewById(R.id.image_resOrder_footer_cart);
        TextView text_count = (TextView) rootView.findViewById(R.id.text_resOrder_footer_count);
        TextView text_noPrice = (TextView) rootView.findViewById(R.id.textView_resOrder_footer_noPrice);
        LinearLayout linear_price = (LinearLayout) rootView.findViewById(R.id.linear_resOrder_footer_price);
        TextView text_price = (TextView) rootView.findViewById(R.id.textView_resOrder_footer_price);
        Button btn_selected = (Button) rootView.findViewById(R.id.btn_resOrder_footer_selected);
        RelativeLayout relative_footer = (RelativeLayout) rootView.findViewById(R.id.relative_resOrder_footer);
    }

    //缓存布局
    class First_ViewHolder {
        ImageView image_pic;
        TextView text_name;
        TextView text_sales;
        TextView text_good;
        TextView text_price;
        LinearLayout linearLayout_select;
        LinearLayout linearLayout_remove;
        ImageView image_remove;
        TextView text_count;
        ImageView image_add;
        TextView text_rest;
    }

    //弹出第二个底部布局
    class TwoFooterClass {
        ImageView image_twoFooter_cart = (ImageView) twoFooterView.findViewById(R.id.image_resOrder_twoFooter_cart);
        TextView text_twoFooter_totalCount = (TextView) twoFooterView.findViewById(R.id.text_resOrder_twoFooter_totalCount);
        TextView text_twoFooter_totalPrice = (TextView) twoFooterView.findViewById(R.id.text_resOrder_twoFooter_totalPrice);
        Button btn_twoFooter_selected = (Button) twoFooterView.findViewById(R.id.btn_resOrder_twoFooter_selected);

        ImageView image_twoFooter_delete = (ImageView) twoFooterView.findViewById(R.id.image_resOrder_twoFooter_delete);
        ListView listView_twoFooter = (ListView) twoFooterView.findViewById(R.id.listView_resOrder_twoFooter);

    }

    //twoFooter的adapter
    class TwoFooterAdapter extends BaseAdapter{

        public TwoFooterAdapter(){}

        @Override
        public int getCount() {
            return Config.listSelectedFoods.get(restatuantId).size();
        }

        @Override
        public Object getItem(int position) {
            return Config.listSelectedFoods.get(restatuantId).get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
           final Two_ViewHolder two_viewHolder;
            Collections.sort(Config.listSelectedFoods.get(restatuantId), new ResOrderSelectedFoodCompare());
            final ResOrderSelectedFood item=Config.listSelectedFoods.get(restatuantId).get(position);
            if (convertView==null){
                two_viewHolder=new Two_ViewHolder();
                convertView=LayoutInflater.from(context).inflate(R.layout.restaturant_order_twofooter_listitem,parent,false);
                two_viewHolder.text_name = (TextView) convertView.findViewById(R.id.text_resOrder_twoFooter_name);
                two_viewHolder.text_count= (TextView) convertView.findViewById(R.id.text_resOrder_twoFooter_count);
                two_viewHolder.text_Price= (TextView) convertView.findViewById(R.id.text_resOrder_twoFooter_price);
                two_viewHolder.image_add= (ImageView) convertView.findViewById(R.id.image_resOrder_twoFooter_add);
                two_viewHolder.image_remove= (ImageView) convertView.findViewById(R.id.image_resOrder_twoFooter_remove);
                convertView.setTag(two_viewHolder);
            }else {
                two_viewHolder= (Two_ViewHolder) convertView.getTag();
            }
            two_viewHolder.text_name.setText(item.getName());
            two_viewHolder.text_count.setText(String.valueOf(item.getCount()));
            two_viewHolder.text_Price.setText("￥"+
             String.valueOf(item.getCount()*item.getSinglePrice()));

            //点击移除图片
            two_viewHolder.image_remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Config.listSelectedFoods.get(restatuantId).get(position).setCount(item.getCount() - 1);
                    two_viewHolder.text_count.setText(String.valueOf(item.getCount()));
                    two_viewHolder.text_Price.setText("￥" +
                            String.valueOf(item.getCount() * item.getSinglePrice()));
                    if (item.getCount()==0){
                        Config.listSelectedFoods.get(restatuantId).remove(position);
                    }

                    Config.listSelectedCount.put(restatuantId,Config.listSelectedCount.get(restatuantId)-1);
                    Config.listSelectedPrice.put(restatuantId,Config.listSelectedPrice.get(restatuantId)-item.getSinglePrice());

                    changeData();
                }
            });
            //点击增加图片
            two_viewHolder.image_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Config.listSelectedFoods.get(restatuantId).get(position).setCount(item.getCount()+1);

                    two_viewHolder.text_count.setText(String.valueOf(item.getCount()));
                    two_viewHolder.text_Price.setText("￥" +
                            String.valueOf(item.getCount() * item.getSinglePrice()));

                    Config.listSelectedCount.put(restatuantId, Config.listSelectedCount.get(restatuantId) + 1);
                    Config.listSelectedPrice.put(restatuantId, Config.listSelectedPrice.get(restatuantId)+item.getSinglePrice());
                    changeData();
                }
            });



            return convertView;
        }
        class Two_ViewHolder {
            TextView text_name;
            ImageView image_add;
            ImageView image_remove;
            TextView text_count;
            TextView text_Price;
        }

    }

}
