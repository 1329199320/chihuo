package com.sdpt.app.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.sdpt.app.Config;

/**
 * Created by Administrator on 2015/10/11.
 */
public class DataOpenHelper extends SQLiteOpenHelper {

    /*
    * Restaurant 表建表语句
    * */
    public static final String CREATE_RESTAURANT="CREATE TABLE " + Config.TABLE_RESTAURANT+" ("+
            Config.RESTAURANT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            Config.RESTAURANT_NAME+" TEXT NOT NULL," +
            Config.RESTAURANT_PHOTO+ " TEXT,"+
            Config.RESTAURANT_DESCRIPTION+" TEXT,"+
            Config.RESTAURANT_ADDRESS+" TEXT NOT NULL," +
            Config.RESTAURANT_STATUS+" TEXT NOT NULL," +
            Config.RESTAURANT_PREFERENTIAL+" TEXT," +
            Config.RESTAURANT_ASSESS+" INTEGER)";

    //assess 表建表语句
    public static final String CREATE_ASSESS="CREATE TABLE " + Config.TABLE_ASSESS+" ("+
            Config.ASSESS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            Config.ASSESS_USER_ID+" INTEGER NOT NULL," +
            Config.ASSESS_RESTAURANT_ID+ " INTEGER NOT NULL,"+
            Config.ASSESS_USER_NAME+" TEXT NOT NULL,"+
            Config.ASSESS_USER_PIC+" TEXT," +
            Config.ASSESS__TIME+" TEXT NOT NULL," +
            Config.ASSESS_RATING+" TEXT," +
            Config.ASSESS_COMMENT+" TEXT)";

    //收货地址表的创建
    public static final String CREATE_ADDRESS="CREATE TABLE "+ Config.TABLE_ADDRESS+" ("+
            Config.ADDRESS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            Config.ADDRESS_CONTACT_NAME+" TEXT NOT NULL," +
            Config.ADDRESS_SEX+ " TEXT NOT NULL,"+
            Config.ADDRESS_PHONE+" TEXT NOT NULL,"+
            Config.ADDRESS_ADDRESS+" TEXT NOT NULL," +
            Config.ADDRESS_ADDRESS_DETAIL+" TEXT," +
            Config.ADDRESS_UPDATE_TIME+" TEXT)";
    //菜式表的创建
    public static final String CREATE_ORDER="CREATE TABLE "+ Config.TABLE_ORDER+" ("+
            Config.ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            Config.ORDER_NAME+" TEXT," +
            Config.ORDER_CLASS_NAME+ " TEXT,"+
            Config.ORDER_CLASS_URL+" TEXT,"+
            Config.ORDER_CLASS_ID+" TEXT," +
            Config.ORDER_IMAGE_URL+" TEXT," +
            Config.ORDER_DESCRIPTION+" TEXT," +
            Config.ORDER_RESTAURANT_ID+" TEXT," +
            Config.ORDER_PRICES+" TEXT," +
            Config.ORDER_CLICK_COUNT+" TEXT," +
            Config.ORDER_STATUS+" TEXT)";

    public DataOpenHelper(Context context, String DBname, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DBname, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_RESTAURANT); //创建Restaurant表
        db.execSQL(CREATE_ASSESS);//创建Assess表 评价表
        db.execSQL(CREATE_ADDRESS);
//        db.execSQL(CREATE_ORDER);
}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
