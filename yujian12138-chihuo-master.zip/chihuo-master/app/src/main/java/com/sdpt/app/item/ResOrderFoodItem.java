package com.sdpt.app.item;

/**
 * Created by Administrator on 2015/10/17.
 *菜式类
 */
public class ResOrderFoodItem {

    private int id; //菜品的id
    private String name;//菜名
    private String className;//菜式的类别名
    private String classUrl;//菜别的图片地址
    private int classId;
    private String imageUrl; //图片地址
    private String description;//描述
    private int restaurant_id;//所在餐厅id
    private float prices;//价格
    private int click_count;//用户选择数量
    private String status;//状态       //1:正常 2:正在下单 3:商家休息中



    public ResOrderFoodItem(){

    }
    public ResOrderFoodItem(int classId,String className){
        this.className=className;
        this.classId=classId;
    }

    public ResOrderFoodItem(int classId,String className, String classUrl){
        this.classId=classId;
        this.className=className;
        this.classUrl=classUrl;
    }
//    public ResOrderFoodItem(int restaurant_id, String name){
//        this.restaurant_id=restaurant_id;
//        this.name=this.name;
//    }
//    public ResOrderFoodItem(int id, String name, String imageUrl){
//        this.id=id;
//        this.name=name;
//        this.imageUrl=imageUrl;
//    }

    public ResOrderFoodItem(int id, String name, float prices){
        this.id=id;
        this.name=name;
        this.prices=prices;
    }

    public ResOrderFoodItem(int id,String name,String description,int restaurant_id,
                            float prices,int click_count,String status){
        this.id=id;this.name=name;this.description=description;
        this.restaurant_id=restaurant_id;this.prices=prices;
        this.click_count=click_count;this.status=status;
    }
    public ResOrderFoodItem(int id,String name,String description,int restaurant_id,
                            float prices,int click_count,String status,
                            int classId){
        this.id=id;this.name=name;this.description=description;
        this.restaurant_id=restaurant_id;this.prices=prices;
        this.click_count=click_count;this.status=status;
        this.classId=classId;
    }
    public ResOrderFoodItem(int id,String name,String description,int restaurant_id,
                            float prices,int click_count,String status,
                            String imageUrl,String className){
        this.id=id;this.name=name;this.description=description;
        this.restaurant_id=restaurant_id;this.prices=prices;
        this.click_count=click_count;this.status=status;
        this.imageUrl=imageUrl;
        this.className=className;
    }
    public ResOrderFoodItem(int id,String name,String description,int restaurant_id,
                            float prices,int click_count,String status,
                            String imageUrl,String className,String classUrl){
        this.id=id;this.name=name;this.description=description;
        this.restaurant_id=restaurant_id;this.prices=prices;
        this.click_count=click_count;this.status=status;
        this.imageUrl=imageUrl;
        this.className=className; this.classUrl=classUrl;
    }


    //set方法
    public void setName(String name) {
        this.name = name;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setRestaurant_id(int restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public void setPrices(float prices) {
        this.prices = prices;
    }

    public void setClick_count(int click_count) {
        this.click_count = click_count;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setClassUrl(String classUrl) {
        this.classUrl = classUrl;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }

    //get方法
    public String getName() {
        return name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public int getRestaurant_id() {
        return restaurant_id;
    }

    public float getPrices() {
        return prices;
    }

    public int getClick_count() {
        return click_count;
    }

    public String getStatus() {
        return status;
    }

    public String getClassName() {
        return className;
    }

    public String getClassUrl() {
        return classUrl;
    }

    public int getClassId() {
        return classId;
    }
}
