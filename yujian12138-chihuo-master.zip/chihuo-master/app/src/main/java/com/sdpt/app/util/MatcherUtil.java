package com.sdpt.app.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Administrator on 2015/10/27.
 */
public class MatcherUtil {

    //匹配是否为学生学号或老师账号
    //@return boolean
    public static boolean isStudentNumber(String str){
//        boolean isNumber=false;

        Pattern p=Pattern.compile("^\\d{6,8}$");
        Matcher m=p.matcher(str);

        return  m.matches();
    }
    public static boolean checkPassword(String str){
//        boolean isNumber=false;

        Pattern p=Pattern.compile("^\\d{6,10}$");
        Matcher m=p.matcher(str);

        return  m.matches();
    }
    public static boolean checkPhoneNumber(String str){
//        boolean isNumber=false;

        Pattern p = Pattern
                .compile("^((13[0-9])|(15[^4,\\D])|(170)|(18[0,5-9])|(14[5,7]))\\d{8}$");
        Matcher m=p.matcher(str);

        return  m.matches();
    }

}
