package com.sdpt.app.model;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * Created by Administrator on 2015/10/17.
 *
 */
public class ResOrderLeftListView extends ListView{

    public ResOrderLeftListView(Context context) {
        super(context);
    }

    public ResOrderLeftListView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ResOrderLeftListView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
