package com.sdpt.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.sdpt.app.R;
import com.sdpt.app.item.ContextOrderUserInfoItem;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/11/10.
 */
public class ContextOrderAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<ContextOrderUserInfoItem> list;

    public ContextOrderAdapter(Context context,ArrayList<ContextOrderUserInfoItem> list){
        this.context=context;
        this.list=list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        ContextOrderUserInfoItem item=list.get(position);
        if (convertView==null){
            convertView= LayoutInflater.from(context).inflate(R.layout.context_order_list_item,null);
            viewHolder=new ViewHolder();
            viewHolder.text_restaurantName= (TextView) convertView.findViewById(R.id.text_contextOrder_listItem_restaurantName);
            viewHolder.text_status= (TextView) convertView.findViewById(R.id.text_contextOrder_listItem_status);
            viewHolder.text_totalPrice= (TextView) convertView.findViewById(R.id.text_contextOrder_listItem_price);
            viewHolder.text_time= (TextView) convertView.findViewById(R.id.text_contextOrder_listItem_time);

            convertView.setTag(viewHolder);
        }else {
            viewHolder= (ViewHolder) convertView.getTag();
        }
        viewHolder.text_restaurantName.setText(item.getRestaurant());
        viewHolder.text_totalPrice.setText(item.getOrder_price());
        viewHolder.text_time.setText(item.getCreate_time());
        changeByStatus(item.getOrder_status(), viewHolder.text_status);

        return convertView;
    }
    //根据不同状态设置不同页面
    //0:已下单 1:商家已接收 2:商家已发货 3:已收到并付款
    //4:已评价 -1:商家拒单 -2:用户取消
    private void changeByStatus(String status,TextView textView){
        int i=Integer.valueOf(status);
        switch (i){
            case 0:
                textView.setText("等待商家回复");
                break;
            case 1:
                textView.setText("商家已收单");
                break;
            case 2:
                textView.setText("商家已发货");
                break;
            case 3:
                textView.setText("未评价");
                break;
            case 4:
                textView.setText("查看评价");
                break;
            case -1:
                textView.setText("商家拒单");
                break;
            case -2:
                textView.setText("该订单已取消");
                break;
        }
    }

    class ViewHolder{
        TextView text_restaurantName;
        TextView text_status;
        TextView text_totalPrice;
        TextView text_time;
    }

}
