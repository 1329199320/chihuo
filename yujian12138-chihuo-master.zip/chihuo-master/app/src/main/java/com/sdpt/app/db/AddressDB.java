package com.sdpt.app.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.sdpt.app.Config;
import com.sdpt.app.item.MyAddressItem;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

/**
 * Created by Z on 2015/11/1.
 */
public class AddressDB  {
    private DataOpenHelper dbOpenHelper;
    private SQLiteDatabase dbWrite;
    private SQLiteDatabase dbReader;
    private static AddressDB addressDB;

    private AddressDB(Context context){
        dbOpenHelper=new DataOpenHelper(context,Config.DB_NAME,null,Config.DB_VERSION);
        dbWrite=dbOpenHelper.getWritableDatabase();
        dbReader=dbOpenHelper.getReadableDatabase();
    }
    public synchronized static AddressDB getInstance(Context context){
        if (addressDB==null){
            addressDB=new AddressDB(context);
        }
        return addressDB;
    }

    public void insertAddress(ContentValues values){
        dbWrite.insert(Config.TABLE_ADDRESS,null,values);
    }
    //获取所有收货地址列表
    public ArrayList<MyAddressItem> selectAll(){
        ArrayList<MyAddressItem> list=new ArrayList<>();
        MyAddressItem item;

        Cursor cursor= dbReader.query(Config.TABLE_ADDRESS, null, null, null, null, null, null, null);
        for (cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext()){
            item=new MyAddressItem(cursor.getInt(cursor.getColumnIndex(Config.ADDRESS_ID)),
                    cursor.getString(cursor.getColumnIndex(Config.ADDRESS_CONTACT_NAME)),
                    cursor.getString(cursor.getColumnIndex(Config.ADDRESS_SEX)),
                    cursor.getString(cursor.getColumnIndex(Config.ADDRESS_PHONE)),
                    cursor.getString(cursor.getColumnIndex(Config.ADDRESS_ADDRESS)),
                    cursor.getString(cursor.getColumnIndex(Config.ADDRESS_ADDRESS_DETAIL)),
                    cursor.getString(cursor.getColumnIndex(Config.ADDRESS_UPDATE_TIME))
            );
            list.add(item);
        }
        Collections.sort(list, new TimeCompare());
        return list;
    }
    //获取指定的地址
    public MyAddressItem selectSingleAddress(int position){
        Cursor cursor=dbReader.query(Config.TABLE_ADDRESS, null, Config.ADDRESS_ID +"=?",
               new String[]{String.valueOf(position)}, null, null, null);
        cursor.moveToFirst();
        MyAddressItem item=new MyAddressItem(cursor.getInt(cursor.getColumnIndex(Config.ADDRESS_ID)),
                cursor.getString(cursor.getColumnIndex(Config.ADDRESS_CONTACT_NAME)),
                cursor.getString(cursor.getColumnIndex(Config.ADDRESS_SEX)),
                cursor.getString(cursor.getColumnIndex(Config.ADDRESS_PHONE)),
                cursor.getString(cursor.getColumnIndex(Config.ADDRESS_ADDRESS)),
                cursor.getString(cursor.getColumnIndex(Config.ADDRESS_ADDRESS_DETAIL)),
                cursor.getString(cursor.getColumnIndex(Config.ADDRESS_UPDATE_TIME)));
        cursor.close();
        return item;
    }
    //更新某条地址
    public void updateAddress(ContentValues values,int position){
        dbWrite.update(Config.TABLE_ADDRESS, values, Config.ADDRESS_ID + "=?", new String[]{String.valueOf(position)});
    }
    //删除某条地址
    public void deleteSingle(int position){
        dbWrite.delete(Config.TABLE_ADDRESS,Config.ADDRESS_ID+"=?",new String[]{String.valueOf(position)});
    }


    //时间比较
    class TimeCompare implements Comparator<MyAddressItem> {

        @Override
        public int compare(MyAddressItem t1, MyAddressItem t2) {
            DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            try {
                Date date1=dateFormat.parse(t1.getUpdateTime());
                Date date2=dateFormat.parse(t2.getUpdateTime());
                if (date1.getTime()>date2.getTime()){
                    return -1;
                }
                if (date1.getTime()<date2.getTime()){
                    return 1;
                }
                else
                    return 0;
            } catch (ParseException e) {
                e.printStackTrace();
            }

            return 0;

        }

    }

}
