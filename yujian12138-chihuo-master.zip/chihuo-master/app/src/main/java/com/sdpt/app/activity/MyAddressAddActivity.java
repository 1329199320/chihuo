package com.sdpt.app.activity;

import android.content.ContentValues;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.db.AddressDB;
import com.sdpt.app.item.MyAddressItem;
import com.sdpt.app.util.MatcherUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
* 添加地址
* */
public class MyAddressAddActivity extends AppCompatActivity {

    private TextView text_toolBar_title;
    private TextView text_toolBar_save;
    private EditText edit_address,edit_addressDetail;
    private EditText edit_contactName,edit_phone;
    private RadioGroup radioGroup_sex;
    private RadioButton radioButton_man,radioButton_woman;
    private Button btn_delete;

    private String address="",addressDetail="";
    private String contactName="",phone="",sex="先生";
    private AddressDB addressDB;
    private int type=0;

    private Toolbar toolbar;

    private int address_id=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_address_add);

        type=getIntent().getIntExtra(MyAddressActivity.TYPE_TO_ADD_ADDRESS,0);
        address_id=getIntent().getIntExtra(Config.ADDRESS_ID,0);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        init();
        initEvent();

    }

    private void init(){
        text_toolBar_title= (TextView) findViewById(R.id.text_myAddressAdd_toolBar_title);
        text_toolBar_save= (TextView) findViewById(R.id.text_myAddressAdd_toolBar_save);

        edit_address= (EditText) findViewById(R.id.edit_myAddressAdd_address);
        edit_addressDetail= (EditText) findViewById(R.id.edit_myAddressAdd_addressDetail);
        edit_contactName= (EditText) findViewById(R.id.edit_myAddressAdd_contactName);
        edit_phone= (EditText) findViewById(R.id.edit_myAddressAdd_phone);

        radioGroup_sex= (RadioGroup) findViewById(R.id.radioGroup_myAddress_sex);
        radioButton_man= (RadioButton) findViewById(R.id.radioButton_myAddressAdd_sexMan);
        radioButton_woman= (RadioButton) findViewById(R.id.radioButton_myAddressAdd_sexWoman);

        btn_delete= (Button) findViewById(R.id.btn_myAddressAdd_del);
        addressDB=AddressDB.getInstance(this);

        if (type==MyAddressActivity.type_add){
            text_toolBar_title.setText("添加地址");
            btn_delete.setVisibility(View.GONE);
        }else if (type==MyAddressActivity.type_edit){
            text_toolBar_title.setText("编辑地址");
            btn_delete.setVisibility(View.VISIBLE);

            MyAddressItem item=addressDB.selectSingleAddress(address_id);
            edit_address.setText(item.getAddress());
            edit_addressDetail.setText(item.getAddressDetail());
            edit_contactName.setText(item.getContactName());
            edit_phone.setText(item.getPhone());
            String sex_type=item.getSex();
            if (sex_type.equals("先生")){
                radioButton_man.setChecked(true);
            }else {
                radioButton_woman.setChecked(true);
            }

            System.out.println(item.getAddressDetail());
        }

    }

    private void initData(){
        address=edit_address.getText().toString().trim();
        addressDetail=edit_addressDetail.getText().toString().trim();
        contactName=edit_contactName.getText().toString().trim();
        phone=edit_phone.getText().toString().trim();
//        sex=radioButton_man.getText().toString();
    }

    private void initEvent(){

        radioGroup_sex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioButton_myAddressAdd_sexWoman) {
                    sex = "女士";
                } else {
                    sex = "先生";
                }
            }
        });

        //保存数据
        text_toolBar_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initData();
                if (!checkInfo()) {
                    return;
                }
                ContentValues values = new ContentValues();
                values.put(Config.ADDRESS_CONTACT_NAME, contactName);
                values.put(Config.ADDRESS_SEX,sex);
                values.put(Config.ADDRESS_PHONE, phone);
                values.put(Config.ADDRESS_ADDRESS, address);
                values.put(Config.ADDRESS_ADDRESS_DETAIL, addressDetail);
                values.put(Config.ADDRESS_UPDATE_TIME, getTime());
                System.out.println(values.toString());

                if (type==MyAddressActivity.type_add) {
                    addressDB.insertAddress(values);
                }else {
                    addressDB.updateAddress(values,address_id);
                }
                Toast.makeText(MyAddressAddActivity.this, "保存成功", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        //删除数据
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addressDB.deleteSingle(address_id);
                finish();
            }
        });
    }

    //时间格式
    private String getTime(){
        String time="";
        DateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        time= format.format(new Date());
        return time;
    }
    //检查添加信息
    private boolean checkInfo(){
        boolean isComplete=true;
        if (TextUtils.isEmpty(edit_contactName.getText().toString().trim())){
            Toast.makeText(this,"联系人不能为空",Toast.LENGTH_SHORT).show();
            isComplete=false;
        }else if (TextUtils.isEmpty(edit_address.getText().toString().trim())){
            Toast.makeText(this,"地址不能为空",Toast.LENGTH_SHORT).show();
            isComplete=false;
        }else if (TextUtils.isEmpty(edit_phone.getText().toString().trim())){
            Toast.makeText(this,"联系号码不能为空",Toast.LENGTH_SHORT).show();
            isComplete=false;
        }else if (!MatcherUtil.checkPhoneNumber(edit_phone.getText().toString().trim())){
            Toast.makeText(this,"请检查号码",Toast.LENGTH_SHORT).show();
            isComplete=false;
        }
        return isComplete;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home: //返回按钮
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
