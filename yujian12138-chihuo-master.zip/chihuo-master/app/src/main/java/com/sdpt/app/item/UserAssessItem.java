package com.sdpt.app.item;

/**
 * Created by Administrator on 2015/10/24.
 */
public class UserAssessItem  {

    private int userId;
    private int restaurantId;
    private String userName;
    private String userPic;
    private String userAssessTime;
    private float rating;
    private String comment;

    public UserAssessItem(int userId,int restaurantId,String userName,String userAssessTime,
                         float rating){
        this.userId=userId;this.restaurantId=restaurantId;
        this.userName=userName;this.userAssessTime=userAssessTime;
        this.rating=rating;
    }
    public UserAssessItem(int userId,int restaurantId,String userName,String userAssessTime,
                          float rating,String comment){
        this.userId=userId;this.restaurantId=restaurantId;
        this.userName=userName;this.userAssessTime=userAssessTime;
        this.rating=rating;this.comment=comment;
    }
    public UserAssessItem(int userId,int restaurantId,String userName,String userAssessTime,
                          float rating,String comment,String userPic){
        this.userId=userId;this.restaurantId=restaurantId;
        this.userName=userName;this.userAssessTime=userAssessTime;
        this.rating=rating;this.comment=comment;
        this.userPic=userPic;
    }


    //set方法
    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setRestaurantId(int restaurantId) {
        this.restaurantId = restaurantId;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserPic(String userPic) {
        this.userPic = userPic;
    }

    public void setUserAssessTime(String userAssessTime) {
        this.userAssessTime = userAssessTime;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    //get方法


    public int getUserId() {
        return userId;
    }

    public int getRestaurantId() {
        return restaurantId;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserPic() {
        return userPic;
    }

    public String getUserAssessTime() {
        return userAssessTime;
    }

    public float getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }
}
