package com.sdpt.app.item;

/**
 * Created by Administrator on 2015/10/6.
 *
 *  DrawerItem 为抽屉布局 Item 的类。
 *   name 为Item的名字
 *   resId 为Item的图片ID
 */
public class DrawerItem  {
    private String name;
    private int resId;
    public DrawerItem(String name,int resId){
        this.name=name;
        this.resId=resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getResId() {
        return resId;
    }

    public String getName() {
        return name;
    }
}
