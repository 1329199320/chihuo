package com.sdpt.app.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.adapter.ResCommentAdapter;
import com.sdpt.app.db.AssessDB;
import com.sdpt.app.item.UserAssessItem;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

/**
 * Created by Administrator on 2015/10/12.
 * RestaurantActivity的评价Fragment
 */
public class RestaurantCommentFragment extends Fragment implements View.OnClickListener,
        CompoundButton.OnCheckedChangeListener{

    private View rootView;
    private TextView text_total,text_food,text_server;//评价text
    private Button btn_all,btn_good,btn_midlle,btn_bad;//评价button
    private ArrayList<Button> listBtn; //button的集合
    private ListView listView;
    private ResCommentAdapter adapter;
    private ArrayList<UserAssessItem> listAssess=null;
    private String restaurantId;
    private AssessDB assessDB;
    private CheckBox checkBox;
    private int btnSelectedItem=0;//选择的按钮
    private String[] assessCount=new String[4];
    private String[] ratingDivs=new String[]{"0","2.9","3.9","5.1"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView=inflater.inflate(R.layout.restaurant_comment, container, false);
        String name=getActivity().getIntent().getStringExtra(Config.RESTAURANT_NAME);
        restaurantId=getActivity().getIntent().getStringExtra(Config.RESTAURANT_ID);

        assessDB=AssessDB.getInstance(getActivity());


        init();
        initEvent();

        return rootView;
    }

    private void initEvent(){
        text_total.setText("5.3");
        text_food.setText("5.2");
        text_server.setText("5.1");
        listAssess=new ArrayList<>();

//        handleData("0", "6");

        assessCount=assessDB.selectCount(restaurantId, ratingDivs);
        setButtonText();
        selectButton(0);
        adapter=new ResCommentAdapter(getActivity(),listAssess);
        listView.setAdapter(adapter);

        btn_all.setOnClickListener(this);
        btn_good.setOnClickListener(this);
        btn_midlle.setOnClickListener(this);
        btn_bad.setOnClickListener(this);
    }
    private void handleData(String ratingSmall,String ratingBig){

        listAssess.add(new UserAssessItem(1, 1, "张三", "2015-5-2", 4));
        listAssess.add(new UserAssessItem(2, 2, "李四", "2015-9-5", 3, "评论"));
        listAssess.add(new UserAssessItem(1, 1, "张三", "2015-10-2", 2, "评论2", "http://img1.imgtn.bdimg.com/it/u=4002069279,2089950254&fm=23&gp=0.jpg"));
        listAssess.add(new UserAssessItem(3, 1, "王五", "2015-10-2", 3, "评论2", "http://img1.imgtn.bdimg.com/it/u=4002069279,2089950254&fm=23&gp=0.jpg"));
        listAssess.add(new UserAssessItem(4, 1, "赵六", "2014-5-8", 1, "评论6"));
        listAssess.add(new UserAssessItem(5, 1, "周立", "2015-2-5", 4, "大环境"));

        assessDB.insertAssess(listAssess);
        listAssess=assessDB.selectAssessByResId(new String[]{restaurantId,ratingSmall,ratingBig});
        Collections.sort(listAssess, new TimeCompare());
    }

    private void selectButton(int i){
        String ratingSmall="",ratingBig="";

        switch (i){
            case 0:
                ratingSmall=ratingDivs[0];ratingBig=ratingDivs[3];
                break;
            case 1:
                ratingSmall=ratingDivs[2];ratingBig=ratingDivs[3];
                break;
            case 2:
                ratingSmall=ratingDivs[1];ratingBig=ratingDivs[2];
                break;
            case 3:
                ratingSmall=ratingDivs[0];ratingBig=ratingDivs[1];
                break;
        }
        listAssess=assessDB.selectAssessByResId(new String[]{restaurantId,ratingSmall,ratingBig});
        Collections.sort(listAssess, new TimeCompare());
        adapter=new ResCommentAdapter(getActivity(),listAssess);
        listView.setAdapter(adapter);
//        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_resComment_all:
                changButtonStyle(btn_all);
                selectButton(0);
                btnSelectedItem=0;
                break;
            case R.id.btn_resComment_good:
                changButtonStyle(btn_good);
                selectButton(1);
                btnSelectedItem=1;
                break;
            case R.id.btn_resComment_middle:
                changButtonStyle(btn_midlle);
                selectButton(2);
                btnSelectedItem=2;
                break;
            case R.id.btn_resComment_bad:
                changButtonStyle(btn_bad);
                btnSelectedItem=3;
                selectButton(3);
                break;
        }

    }

    //改变button 的style
    private void changButtonStyle(Button btn){
        for (int i=0;i<listBtn.size();i++){
            if (listBtn.get(i)==btn){
                listBtn.get(i).setBackgroundResource(R.color.button_background_light);
                listBtn.get(i).setTextColor(Color.WHITE);
            }else {
                listBtn.get(i).setBackgroundResource(R.color.button_background_white);
                listBtn.get(i).setTextColor(Color.BLACK);
            }
        }
    }

    //初始化控件
    private void init(){
        text_total= (TextView) rootView.findViewById(R.id.text_resComment_total);
        text_food= (TextView) rootView.findViewById(R.id.text_resComment_food);
        text_server= (TextView) rootView.findViewById(R.id.text_resComment_server);

        btn_all= (Button) rootView.findViewById(R.id.btn_resComment_all);
        btn_good= (Button) rootView.findViewById(R.id.btn_resComment_good);
        btn_midlle= (Button) rootView.findViewById(R.id.btn_resComment_middle);
        btn_bad= (Button) rootView.findViewById(R.id.btn_resComment_bad);

        listBtn=new ArrayList<Button>();
        listBtn.add(btn_all);
        listBtn.add(btn_good);
        listBtn.add(btn_midlle);
        listBtn.add(btn_bad);

        listView= (ListView) rootView.findViewById(R.id.listView_resComment);
        checkBox= (CheckBox) rootView.findViewById(R.id.checkbox_resComment);
        checkBox.setOnCheckedChangeListener(this);
    }

    private void setButtonText(){
        if (assessCount!=null){
            btn_all.setText("全部("+assessCount[0]+")");
            btn_good.setText("好评("+assessCount[1]+")");
            btn_midlle.setText("中评("+assessCount[2]+")");
            btn_bad.setText("差评("+assessCount[3]+")");
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if (b){
            for (int i=0;i<listAssess.size();i++){
                if (TextUtils.isEmpty(listAssess.get(i).getComment())){
                 listAssess.remove(i);
                }
            }
            adapter.notifyDataSetChanged();
        }
        else
        {
            selectButton(btnSelectedItem);
        }
    }

    //时间比较
    class TimeCompare implements Comparator<UserAssessItem> {

        @Override
        public int compare(UserAssessItem t1, UserAssessItem t2) {
            DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
            try {
                Date date1=dateFormat.parse(t1.getUserAssessTime());
                Date date2=dateFormat.parse(t2.getUserAssessTime());
                if (date1.getTime()>date2.getTime()){
                    return -1;
                }
                if (date1.getTime()<date2.getTime()){
                    return 1;
                }
                else
                    return 0;
            } catch (ParseException e) {
                e.printStackTrace();
            }

            return 0;

        }

    }


}
