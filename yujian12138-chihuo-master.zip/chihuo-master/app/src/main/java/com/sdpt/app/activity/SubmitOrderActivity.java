package com.sdpt.app.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.db.AddressDB;
import com.sdpt.app.item.MyAddressItem;
import com.sdpt.app.item.ResOrderSelectedFood;
import com.sdpt.app.net.HttpCallBackListener;
import com.sdpt.app.net.PostJsonNetConnection;
import com.sdpt.app.util.ResOrderSelectedFoodCompare;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Z on 2015/11/2.
 *
 * 提交订单
 */
public class SubmitOrderActivity extends AppCompatActivity implements View.OnClickListener{

//    private String restaurantId=null;
    //联系人的信息控件
    private TextView text_contactName,text_sex,text_phone;
    private TextView text_address,text_addressDetail;
    private ImageView image_editAddress;
    private LinearLayout linear_haveAddress, linear_noAddress;
    //商家的控件
    private TextView text_restaurantName;
    private ListView listView_foods;
    //底部控件
    private TextView text_foodTotalPrice;
    private Button btn_submit;


    public static final int SUBMIT_REQUEST_LOGIN =1;
    public static final int SUBMIT_REQUEST_ADDRESS=2;
    private AddressDB addressDB;
    private boolean isExitAddress=true; //是否存在用户地址 ，true 存在 ，false 不存在

    private String restaurantId="";
    private ArrayList<ResOrderSelectedFood> arrayList=null;
    private MyAddressItem addressItem=null;
    private String userId="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_order);

        restaurantId=getIntent().getStringExtra(Config.RESTAURANT_ID);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();
        initData();

        if (!isLogin()){
            return;
        }
        checkAddress();
        listView();
        initEvent();
    }

    private void checkAddress(){
        //判断是否有地址
        if (addressDB.selectAll().size()==0){ //没有地址时

            linear_haveAddress.setVisibility(View.GONE);
            linear_noAddress.setVisibility(View.VISIBLE);

            isExitAddress=false;
        }else {    //有地址
            linear_haveAddress.setVisibility(View.VISIBLE);
            linear_noAddress.setVisibility(View.GONE);
            isExitAddress=true;

            addressItem=addressDB.selectAll().get(0);
            text_contactName.setText(addressItem.getContactName());
            text_sex.setText(addressItem.getSex());
            text_phone.setText(addressItem.getPhone());
            text_address.setText(addressItem.getAddress());
            text_addressDetail.setText(addressItem.getAddressDetail());

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initData();
        checkAddress();
        listView();
        initEvent();

    }

    //检查是否登陆
    private boolean isLogin(){
        SharedPreferences sharedPreferences=getSharedPreferences(Config.APP_ID, MODE_PRIVATE);
         userId=sharedPreferences.getString(Config.USER_ID,"");
        if (TextUtils.isEmpty(userId)){
            Toast.makeText(this,"请先登陆",Toast.LENGTH_SHORT).show();
            startActivityForResult(new Intent(this, MyLoginActivity.class), SUBMIT_REQUEST_LOGIN);
            return false;
        }
        return true;
    }

    private void listView(){
        List<HashMap<String,String>> list=new ArrayList<HashMap<String,String>>();
        arrayList=Config.listSelectedFoods.get(restaurantId);
        if (arrayList.size()<1){
            finish();
            Toast.makeText(this,"没有数据",Toast.LENGTH_SHORT).show();
        }

        for (int i=0;i<arrayList.size();i++){
            HashMap<String,String> hashMap=new HashMap<String,String>();
            hashMap.put("name",arrayList.get(i).getName());
            hashMap.put("count",String.valueOf(arrayList.get(i).getCount()));
            hashMap.put("price",String.valueOf(arrayList.get(i).getSinglePrice()
            *arrayList.get(i).getCount()));
            list.add(hashMap);
        }
        for (int n=0;n<list.size();n++){
            System.out.println(list.get(n).get("name"));
        }

        SimpleAdapter simpleAdapter=new SimpleAdapter(this,list,
                R.layout.submit_order_list_item,
                new String[]{"name","count","price"},
                new int[]{R.id.text_submitOrder_listItem_name,
                R.id.text_submitOrder_listItem_count,R.id.text_submitOrder_listItem_price});

        listView_foods.setAdapter(simpleAdapter);
        text_foodTotalPrice.setText(Config.listSelectedPrice.get(restaurantId).toString());
    }

    private void initEvent(){
        //编辑地址图片按钮
        image_editAddress.setOnClickListener(this);
        //提交订单
        btn_submit.setOnClickListener(this);
    }

    //初始化控件
    private void init(){
        //联系人控件
        text_contactName= (TextView) findViewById(R.id.text_submit_contactName);
        text_sex= (TextView) findViewById(R.id.text_submit_sex);
        text_phone= (TextView) findViewById(R.id.text_submit_phone);
        text_address= (TextView) findViewById(R.id.text_submit_address);
        text_addressDetail= (TextView) findViewById(R.id.text_submit_addressDetail);
        image_editAddress= (ImageView) findViewById(R.id.image_submit_editAddress);
        linear_haveAddress = (LinearLayout) findViewById(R.id.linear_haveAddress);
        linear_noAddress= (LinearLayout) findViewById(R.id.linear_noAddress);
        //商家
        text_restaurantName= (TextView) findViewById(R.id.text_submit_restaurant_name);
        listView_foods= (ListView) findViewById(R.id.list_submit_foods);
        //底部
        text_foodTotalPrice= (TextView) findViewById(R.id.text_submit_foodTotalPrice);
        btn_submit= (Button) findViewById(R.id.btn_submit_submit);
    }
    //初始化数据
    private void initData(){
        addressDB=AddressDB.getInstance(this);
        restaurantId=getIntent().getStringExtra(Config.RESTAURANT_ID);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.image_submit_editAddress:
                Intent intent=new Intent(SubmitOrderActivity.this,MyAddressAddActivity.class);
                if (!isExitAddress){
                    intent.putExtra(MyAddressActivity.TYPE_TO_ADD_ADDRESS,MyAddressActivity.type_add);
                }else {
                    ArrayList<MyAddressItem> addressItems=addressDB.selectAll();
                    intent.putExtra(MyAddressActivity.TYPE_TO_ADD_ADDRESS,MyAddressActivity.type_edit);
                    intent.putExtra(Config.ADDRESS_ID, addressItems.get(0).getId());
                }
                startActivity(intent);
                break;
            case R.id.btn_submit_submit:
                if (!isLogin()){
                    return;
                }else if (!isExitAddress){
                    Toast.makeText(SubmitOrderActivity.this,"请填写收餐人的信息",Toast.LENGTH_SHORT).show();
                }else {
//                    http://dingcan.coding.io/api/user/demo/type/json
//                    new PostJsonNetConnection("http://dingcan.coding.io/api/order/orderSubmit",
//                    new PostJsonNetConnection("http://dingcan.coding.io/api/user/demo/type/json",
                    new PostJsonNetConnection(Config.POST_SUBMIT_URL,
//                    new PostJsonNetConnection("http://kazamigakuen.oicp.net/api/order/orderSubmit",
                            new HttpCallBackListener() {
                                @Override
                                public void onFinish(String response) {
//                                    System.out.println(response.toString());
//                                    Config.listSelectedFoods.clear();
                                    try {
                                        JSONObject jsonObject=new JSONObject(response);
                                        String status=jsonObject.getString("status");
                                        if (status.equals("1")){
//                                            System.out.println("11111");
                                            new AlertDialog.Builder(SubmitOrderActivity.this)
                                                    .setTitle("提示")
                                                    .setMessage("下单成功")
                                                    .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialogInterface, int i) {
                                                            Config.listSelectedFoods.remove(restaurantId);
                                                            Config.listSelectedPrice.remove(restaurantId);
                                                            Config.listSelectedCount.remove(restaurantId);
                                                            startActivity(new Intent(SubmitOrderActivity.this, ContextMainActivity.class));
                                                            finish();
                                                        }
                                                    }).show();

                                        }else {
//                                            System.out.println("00000000");
                                            new AlertDialog.Builder(SubmitOrderActivity.this)
                                                    .setTitle("提示")
                                                    .setMessage("下单失败")
                                                    .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialogInterface, int i) {
                                                            startActivity(new Intent(SubmitOrderActivity.this, ContextMainActivity.class));

                                                        }
                                                    }).show();
                                        }

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }


                                }
                                @Override
                                public void onError() {

                                }
                            },sendJsonData());
                }
                break;
        }
    }

    private String sendJsonData() {
        String s = "";
        try {
            JSONObject jsonRoot = new JSONObject();
            JSONArray array = new JSONArray();
            Collections.sort(Config.selectedFoods, new ResOrderSelectedFoodCompare());

            for (int i = 0; i <arrayList.size(); i++) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("fooID", arrayList.get(i).getId());
//                jsonObject.put("fooName",arrayList.get(i).getName());
                jsonObject.put("fooCount",arrayList.get(i).getCount());
                jsonObject.put("singlePrice",arrayList.get(i).getSinglePrice());
                array.put(jsonObject);
            }
            jsonRoot.put("userID",userId);

            jsonRoot.put("restaurantID", restaurantId);
            jsonRoot.put("totalPrice",Config.listSelectedPrice.get(restaurantId));
            jsonRoot.put("data", array);

            JSONObject json_address=new JSONObject();
            json_address.put(Config.ADDRESS_CONTACT_NAME, addressItem.getContactName());
            json_address.put(Config.ADDRESS_SEX, addressItem.getSex());
            json_address.put(Config.ADDRESS_PHONE, addressItem.getPhone());
            json_address.put(Config.ADDRESS_ADDRESS, addressItem.getAddress());
            json_address.put(Config.ADDRESS_ADDRESS_DETAIL, addressItem.getAddressDetail());

            jsonRoot.put("address",json_address);

            s = jsonRoot.toString();
            System.out.println(s);
            return s;

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return s;
    }
}
