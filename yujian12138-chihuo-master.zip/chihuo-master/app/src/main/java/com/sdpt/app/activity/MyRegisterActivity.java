package com.sdpt.app.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.net.HttpCallBackListener;
import com.sdpt.app.net.NetWorkState;
import com.sdpt.app.net.PostNetConnection;
import com.sdpt.app.util.MD5Tool;
import com.sdpt.app.util.MatcherUtil;

import org.json.JSONException;
import org.json.JSONObject;

/*
* 用户注册
* */
public class MyRegisterActivity extends AppCompatActivity {

    private TextView  text_userName,text_password,text_checkPassword;
//    private TextView text_login;
    private Button btn_register;
    private EditText edit_userName,edit_password,edit_checkPassword;
    private String str_userName,str_password,str_checkPassword;
    private boolean isEqual=false;//判断密码是否一致


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_register);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);

        init();
        initEvent();
    }

    private void initEvent(){
        str_userName=edit_userName.getText().toString().trim();

        //注册按钮的提交
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPasswordEqual();
                checkUserName();
                checkPassword();
                if (checkUserName() && checkPassword() && checkPasswordEqual()) {
                    String password = edit_password.getText().toString().trim();
                    password = MD5Tool.md5(password);

                    upLoad(edit_userName.getText().toString().trim(), password);
                } else {
                    Toast.makeText(MyRegisterActivity.this, "请检查输入信息！", Toast.LENGTH_LONG).show();
                }
            }
        });



        //检查密码
        edit_password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b){
                    edit_password.setText("");
                }else {
                    checkPassword();
                }
            }
        });

        //确认密码是否一致
        edit_checkPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    text_checkPassword.setText("");
                } else {
                    checkPasswordEqual();
                }
            }
        });
        //用户检查
        edit_userName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    text_userName.setText("");
                } else {
                    checkUserName();
                }
            }
        });
        //登陆跳转按钮
//        text_login.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(MyRegisterActivity.this,MyLoginActivity.class));
//            }
//        });


    }

    private void upLoad(String userName,String password){
        if (!NetWorkState.isNetworkOpen(MyRegisterActivity.this)){
            Toast.makeText(MyRegisterActivity.this,"请检查网络",Toast.LENGTH_LONG).show();
            return;
        }
        new PostNetConnection(Config.POST_REGISTER_URL, new HttpCallBackListener() {
            @Override
            public void onFinish(String response) {
//                0：数据库有问题； -1:用户已存在 ； -2:账户格式不对 ； -3:密码为空
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    String status=jsonObject.getString("status");
                    if (status.equals("0")){
                        Toast.makeText(MyRegisterActivity.this,"服务器异常",Toast.LENGTH_LONG).show();
                    }else if (status.equals("-1")){
                        Toast.makeText(MyRegisterActivity.this,"用户已存在",Toast.LENGTH_LONG).show();
                    }else if (status.equals("-2")){
                        Toast.makeText(MyRegisterActivity.this,"账户格式不对",Toast.LENGTH_LONG).show();
                    }else if (status.equals("-3")){
                        Toast.makeText(MyRegisterActivity.this,"密码为空",Toast.LENGTH_LONG).show();
                    }else if (status.equals("1")){
                        Toast.makeText(MyRegisterActivity.this,"注册成功",Toast.LENGTH_LONG).show();

                        //存入数据
                        String userId=jsonObject.getString("info");
                        SharedPreferences.Editor editor=getSharedPreferences(Config.APP_ID,MODE_PRIVATE).edit();
                        editor.putString(Config.USER_ID, userId);
                        editor.putString(Config.USER_NAME, edit_userName.getText().toString());
                        editor.commit();
//                        SharedPreferences sharedPreferences=getSharedPreferences(Config.APP_ID,MODE_PRIVATE);
//                        String s=sharedPreferences.getString(Config.USER_ID,"");
//                        Toast.makeText(MyRegisterActivity.this,s,Toast.LENGTH_LONG).show();
//                        startActivity(new Intent(MyRegisterActivity.this, MyLoginActivity.class));
                        Intent intent=new Intent();
                        intent.putExtra(Config.USER_ID,userId);
                        intent.putExtra(Config.USER_NAME,edit_userName.getText().toString());
                        setResult(RESULT_OK,intent);
                        finish();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                System.out.println("+++++++++++++"+response);
            }
            @Override
            public void onError() {

            }
        },Config.POST_USER_NAME,userName,Config.POST_USER_PASSWORD,password);
    }

    //判断账号属性
    private boolean checkUserName(){
        if (TextUtils.isEmpty(edit_userName.getText())){
            text_userName.setText("账号不能为空");
            return false;
        }else if (!MatcherUtil.isStudentNumber(edit_userName.getText().toString().trim())){
            text_userName.setText("教工号或学号");
            return false;
        }else {
            return true;
        }
    }
    //判断密码
    private boolean checkPassword(){
        if (TextUtils.isEmpty(edit_password.getText().toString())){
            text_password.setText("密码不能为空");
            return false;
        }else if (edit_password.getText().toString().trim().length()<6){
            text_password.setText("密码大于5位");
            return false;
        }else {
            text_password.setText("");
            return true;
        }

    }
    //判断密码是否一致
    private boolean checkPasswordEqual(){
        if (edit_checkPassword.getText().toString().trim().equals(edit_password.getText().toString().trim())){
            text_checkPassword.setText("");
            return true;

        }else {
            text_checkPassword.setText("密码不一致");
            return  false;
        }
    }

     private void init(){
        text_userName= (TextView) findViewById(R.id.text_myRegister_userName);
        text_password= (TextView) findViewById(R.id.text_myRegister_password);
        text_checkPassword= (TextView) findViewById(R.id.text_myRegister_checkPassword);
//        text_login= (TextView) findViewById(R.id.text_myRegister_login);

        edit_userName= (EditText) findViewById(R.id.editText_myRegister_userName);
        edit_password= (EditText) findViewById(R.id.editText_myRegister_password);
        edit_checkPassword= (EditText) findViewById(R.id.editText_myRegister_checkPassword);

        text_checkPassword.setText("");
        text_userName.setText("");
        text_password.setText("");

        btn_register= (Button) findViewById(R.id.button_myRegister_register);
    }


}
