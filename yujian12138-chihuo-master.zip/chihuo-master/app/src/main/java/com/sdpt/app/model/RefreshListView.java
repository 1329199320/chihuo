package com.sdpt.app.model;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.sdpt.app.R;

/**
 * Created by Administrator on 2015/10/13.
 */
public class RefreshListView extends ListView implements AbsListView.OnScrollListener{
//public class RefreshListView extends ListView {

    View  headerView;
    int headerViewHeight;//顶部布局文件的高度
    int firstListItem;//当前listView第一个可见Item的位置
    int scrollState;//当前滚动的状态
    boolean isRemark;// 标记，当前是在listView最顶端摁下的
    int startY;//开始摁下的Y值
    int viewPagerHeight=120;

    int state;//当前状态
    final int STATE_NONE=0;//正常状态
    final int STATE_PULL=1;//下拉状态
    final int STATE_RELEASE=2;//释放状态
    final int STATE_REFRESHING =3;//正在刷新状态

    OnRefreshListener onRefreshListener;

    private TextView textView_tip;
//    private TextView textView_UpdateTime;
    private ImageView imageArrow;
    private ProgressBar progressBar;


    public RefreshListView(Context context) {
        super(context);
        initView(context);
    }

    public RefreshListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public RefreshListView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }


    private void initView(Context context){
        headerView= LayoutInflater.from(context).inflate(R.layout.refresh_header, null);
        measureView(headerView);
        headerViewHeight=headerView.getMeasuredHeight();
        topPadding(-headerViewHeight);
        RefreshListView.this.addHeaderView(headerView);
        RefreshListView.this.setOnScrollListener(this);
    }

    private void measureView(View view){
        ViewGroup.LayoutParams p=view.getLayoutParams();
        if (p==null){
            p=new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                         ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        int width=ViewGroup.getChildMeasureSpec(0, 0, p.width);
        int height;
        int tempHeight=p.height;
        if (tempHeight>0){
            height=MeasureSpec.makeMeasureSpec(tempHeight,MeasureSpec.EXACTLY);
        }else {
            height=MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED);
        }
        view.measure(width, height);

    }

    /*
    * 设置布局的上边距
    * @param int topPadding
    * */
    private void topPadding(int topPadding){
        headerView.setPadding(headerView.getPaddingLeft(), topPadding,
                headerView.getPaddingRight(), headerView.getPaddingBottom());
        headerView.invalidate();
    }

    //listView触摸事件
    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getAction()){
            case MotionEvent.ACTION_DOWN:
//                if (firstListItem==0){
                    isRemark=true;
                    startY= (int) ev.getY();
//                }
                break;
            case MotionEvent.ACTION_MOVE:
                onMove(ev);
                break;
            case MotionEvent.ACTION_UP:
                if (state==STATE_RELEASE){
                    state=STATE_REFRESHING;
                    changeViewByState();
                    onRefreshListener.onRefresh();
                }else if (state==STATE_PULL){
                    state=STATE_NONE;
                    isRemark=false;
                    changeViewByState();
                }
                break;
        }
        return super.onTouchEvent(ev);
    }
    /*
    * 判断移动过程
    * */
    private void onMove(MotionEvent event){
        if (!isRemark){
            return;
        }
        int tempY= (int) event.getY();
        int space=tempY-startY;
        int topPadding=space-headerViewHeight;
        if (topPadding>headerViewHeight){
            topPadding=headerViewHeight-30;
        }
//        System.out.println("-------------- space"+space);
//        System.out.println("-------------- topPadding"+topPadding);
//        System.out.println("-------------- hh"+headerViewHeight);
        switch (state){
            case STATE_NONE:
                if (space>0){
                    state=STATE_PULL;
                    changeViewByState();
                }
                break;
            case STATE_PULL:
                topPadding(topPadding);
                if (space>headerViewHeight+10&&scrollState==SCROLL_STATE_TOUCH_SCROLL){
//                if (space>headerViewHeight+10){
                    state=STATE_RELEASE;
                    changeViewByState();
                }
                break;
            case STATE_RELEASE:
                topPadding(topPadding);
                if (space<headerViewHeight+10){
                    state=STATE_PULL;
                    changeViewByState();
                }else if (space<=0){
                    state=STATE_NONE;
                    isRemark=false;
                    changeViewByState();
                }
                break;

        }
    }

    /*
    * 根据当前状态改变header页面
    * */
    private void changeViewByState(){
        textView_tip = (TextView) headerView.findViewById(R.id.refresh_tip);
//        textView_UpdateTime= (TextView) headerView.findViewById(R.id.refresh_lastUpdate_time);
        imageArrow= (ImageView) headerView.findViewById(R.id.refresh_arrow);
        progressBar= (ProgressBar) headerView.findViewById(R.id.refresh_progress);

        RotateAnimation animUp=new RotateAnimation(0,180,RotateAnimation.RELATIVE_TO_SELF,0.5f,
                RotateAnimation.RELATIVE_TO_SELF,0.5f);
        animUp.setDuration(500);
        animUp.setFillAfter(true);
        RotateAnimation animDown=new RotateAnimation(180,0,RotateAnimation.RELATIVE_TO_SELF,0.5f,
                RotateAnimation.RELATIVE_TO_SELF,0.5f);
        animDown.setDuration(500);
        animDown.setFillAfter(true);

        switch (state){
            case STATE_NONE:
                topPadding(-headerViewHeight);
                break;
            case STATE_PULL:
                imageArrow.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
                textView_tip.setText("下拉可以刷新");
                imageArrow.clearAnimation();
                imageArrow.setAnimation(animDown);
                break;
            case STATE_RELEASE:
                imageArrow.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
                textView_tip.setText("松开可以刷新");
                imageArrow.clearAnimation();
                imageArrow.setAnimation(animUp);
                break;
            case STATE_REFRESHING:
                topPadding(20);
                imageArrow.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
                textView_tip.setText("正在刷新...");
                imageArrow.clearAnimation();
                break;
        }

    }
    /*
    * 获取完数据
    * */
    public  void refreshComplete(){
        state=STATE_NONE;
        changeViewByState();

    }
    public void setOnRefreshListener(OnRefreshListener onRefreshListener){
        this.onRefreshListener=onRefreshListener;
    }



    public interface OnRefreshListener {
        public void onRefresh();
    }

    @Override
    public void onScrollStateChanged(AbsListView absListView, int scrollState) {
        this.scrollState=scrollState;
    }

    @Override
    public void onScroll(AbsListView absListView, int firstListItem, int visibleItemCount, int totalItemCount) {
//        this.firstListItem=firstListItem;
    }




}
