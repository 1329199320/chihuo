package com.sdpt.app.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.sdpt.app.Config;
import com.sdpt.app.item.Restaurant;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2015/10/11.
 *数据库处理类。
 * 获取该类 为 getInstance() 方法。
 */
public class MainDB {
    private DataOpenHelper dbHelper; //声明DataOpenHelper
    private SQLiteDatabase dbWrite;  //获取写入数据库的权限
    private SQLiteDatabase dbReader; //获取读取数据库的权限
    private static MainDB mainDB;

    /*
    * 将构造方法私有化
    * */
    private MainDB(Context context) {
        dbHelper = new DataOpenHelper(context, Config.DB_NAME, null, Config.DB_VERSION);
        dbWrite = dbHelper.getWritableDatabase();
        dbReader = dbHelper.getReadableDatabase();
    }

    /*
    * 获取MainDB的实例
    * */
    public synchronized static MainDB getInstance(Context context) {
        if (mainDB == null) {
            mainDB = new MainDB(context);
        }
        return mainDB;
    }

    //将Restaurant实例存储到数据库。
//    public void insertRestaurant(Restaurant restaurant) {
    public void insertRestaurant(ContentValues values){
        if (values != null) {
            dbWrite.insert(Config.TABLE_RESTAURANT, null, values);
        }
    }

    //查询所有在Restaurant的数据
    //@return cursor
    public List<Restaurant> selectAllRestaurant() {
        Cursor cursor = dbReader.query(Config.TABLE_RESTAURANT, null, null, null, null, null, null);
        ArrayList<Restaurant> list=new ArrayList<>();
        Restaurant restaurant;
        for (cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext()){
            restaurant=new Restaurant(cursor.getInt(cursor.getColumnIndex(Config.RESTAURANT_ID)),
                    cursor.getString(cursor.getColumnIndex(Config.RESTAURANT_NAME)),
                    cursor.getString(cursor.getColumnIndex(Config.RESTAURANT_PHOTO)),
                    cursor.getString(cursor.getColumnIndex(Config.RESTAURANT_DESCRIPTION)),
                    cursor.getString(cursor.getColumnIndex(Config.RESTAURANT_ADDRESS)),
                    cursor.getString(cursor.getColumnIndex(Config.RESTAURANT_STATUS)),
                    cursor.getString(cursor.getColumnIndex(Config.RESTAURANT_PREFERENTIAL)),
                    cursor.getInt(cursor.getColumnIndex(Config.RESTAURANT_ASSESS)));
            list.add(restaurant);
        }

        return list;
    }

    /*
    * 判断某条Restaurant数据是否存在。
    * @param String[] selectId  要查询的Id
    * @return boolean
    * */
    public boolean isExitsRestaurantId(String[] selectId) {
        Cursor cursor1 = dbReader.query(Config.TABLE_RESTAURANT, null, Config.RESTAURANT_ID+"=?", selectId, null, null, null);
        if (cursor1.getCount() >0) {
            return true;
        }else {
            return false;
        }
    }
    public Cursor selectRestaurant(String[] selectId) {
        Cursor cursor1 = dbReader.query(Config.TABLE_RESTAURANT, null, Config.RESTAURANT_ID+"=?", selectId, null, null, null);

        return cursor1;
    }

    /*
    * 更新Restaurant的信息
    * @param ContentValues 要更新的信息
    * @param String where 什么条件
    * @param String whereArgs 条件值
    * */
    public void updateRestaurantInfo(ContentValues updateValues,String where,String[] whereArgs){
        dbWrite.update(Config.TABLE_RESTAURANT,updateValues,where,whereArgs);
    }
}