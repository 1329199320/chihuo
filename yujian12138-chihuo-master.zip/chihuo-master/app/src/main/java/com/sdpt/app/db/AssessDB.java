package com.sdpt.app.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.sdpt.app.Config;
import com.sdpt.app.item.UserAssessItem;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/24.
 *处理Assess表的事务
 */
public class AssessDB  {
    private DataOpenHelper dbHelper;
    private SQLiteDatabase dbWrite;
    private SQLiteDatabase dbReader;
    private static AssessDB assessDB;

    //将构造方法私有化
    private AssessDB(Context context){
        dbHelper=new DataOpenHelper(context, Config.DB_NAME,null,Config.DB_VERSION);
        dbWrite=dbHelper.getWritableDatabase();
        dbReader=dbHelper.getReadableDatabase();
    }
    //获取Assess的实例
    public synchronized static AssessDB getInstance(Context context){
        if (assessDB==null){
            assessDB=new AssessDB(context);
        }
        return assessDB;
    }
    //插入数据
    public void insertAssess(ArrayList<UserAssessItem> list){
        ContentValues values;
        for (int i=0;i<list.size();i++){
            values=new ContentValues();
            values.put(Config.ASSESS_USER_ID,list.get(i).getUserId()) ;
            values.put(Config.ASSESS_RESTAURANT_ID,list.get(i).getRestaurantId()) ;
            values.put(Config.ASSESS_USER_NAME,list.get(i).getUserName()) ;
            values.put(Config.ASSESS_USER_PIC,list.get(i).getUserPic()) ;
            values.put(Config.ASSESS__TIME,list.get(i).getUserAssessTime()) ;
            values.put(Config.ASSESS_RATING,list.get(i).getRating()) ;
            values.put(Config.ASSESS_COMMENT,list.get(i).getComment()) ;

            dbWrite.insert(Config.TABLE_ASSESS,null,values);
        }
    }

    public ArrayList<UserAssessItem> selectAssessByResId(String[] resIdsAndRating){
        Cursor cursor=dbReader.query(Config.TABLE_ASSESS,null,
                Config.ASSESS_RESTAURANT_ID+"=? and "+
                Config.ASSESS_RATING+">? and "+
                Config.ASSESS_RATING+"<?",resIdsAndRating,null,null,null);
        ArrayList<UserAssessItem> list=new ArrayList<>();
        UserAssessItem item;
        for (cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext()){
            item=new UserAssessItem(cursor.getInt(cursor.getColumnIndex(Config.ASSESS_USER_ID)),
                    cursor.getInt(cursor.getColumnIndex(Config.ASSESS_RESTAURANT_ID)),
                    cursor.getString(cursor.getColumnIndex(Config.ASSESS_USER_NAME)),
                    cursor.getString(cursor.getColumnIndex(Config.ASSESS__TIME)),
                    cursor.getFloat(cursor.getColumnIndex(Config.ASSESS_RATING)),
                    cursor.getString(cursor.getColumnIndex(Config.ASSESS_COMMENT)),
                    cursor.getString(cursor.getColumnIndex(Config.ASSESS_USER_PIC)));
            list.add(item);
        }
       return list;
    }

    public String[] selectCount(String resId ,String[] classDiv){
        String[] count=new String[4];
        String[] select=new String[3];
        Cursor cursor;
        select[0]=resId;
        for (int i=0;i<classDiv.length;i++) {
            switch (i){
                case 0:
                    select[1] = classDiv[0];
                    select[2] = classDiv[3];
                    break;
                case 1:
                    select[1] = classDiv[2];
                    select[2] = classDiv[3];
                    break;
                case 2:
                    select[1] = classDiv[1];
                    select[2] = classDiv[2];
                    break;
                case 3:
                    select[1] = classDiv[0];
                    select[2] = classDiv[1];
                    break;
            }
            cursor = dbReader.query(Config.TABLE_ASSESS, null,
                    Config.ASSESS_RESTAURANT_ID + "=? and " +
                            Config.ASSESS_RATING + ">? and " +
                            Config.ASSESS_RATING + "<?", select, null, null, null);
            count[i]=String.valueOf(cursor.getCount());
        }
        return count;
    }


}
