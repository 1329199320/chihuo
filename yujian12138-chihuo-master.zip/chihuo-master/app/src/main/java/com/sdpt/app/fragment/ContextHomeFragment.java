package com.sdpt.app.fragment;


import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.adapter.HomeItemAdapter;
import com.sdpt.app.adapter.ViewPageAdapter;
import com.sdpt.app.db.MainDB;
import com.sdpt.app.item.Restaurant;
import com.sdpt.app.model.RefreshListView;
import com.sdpt.app.model.RefreshListView.OnRefreshListener;
import com.sdpt.app.net.HttpCallBackListener;
import com.sdpt.app.net.NetConnection;
import com.sdpt.app.net.NetWorkState;
import com.sdpt.app.activity.RestaurantActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by Administrator on 2015/10/6.
 */
public class ContextHomeFragment extends Fragment {

    private View rootView;
    //ViewPager 声明
    private ViewPager viewPager;
    private List<View> viewLists;
    private ViewPageAdapter pageAdapter;
    private RelativeLayout relativeLayout_viewPager;
    private TextView textView_viewPage_introduce;
    private ImageView[] imageViewPoints;
    private ImageView[] imageViewsPagers;
//    private ImageView imageViewPager;
    private int[] viewPagerResId={R.drawable.viewpager_home1,R.drawable.viewpager_home2,
                                      R.drawable.viewpager_home3,R.drawable.viewpager_home4};
    private int[] pointsId={R.id.imageView_contextHome_point1,R.id.imageView_contextHome_point2,
                               R.id.imageView_contextHome_point3,R.id.imageView_contextHome_point4};
    private String[] viewPage_introduce={"荷苑","竹苑","桃苑","小飞象"};
    private static final int AUTO_VIEWPAGER=10000;
    private static final int TIME_VIEWPAGER=10000;
    private AtomicInteger what = new AtomicInteger(0);

    private MainDB mainDB;
    private RefreshListView listView;//刷新页面
    private ArrayList<Restaurant> listRestaurant=new ArrayList<>();
//    public static boolean isFirstLoad=false;//是否为第一次加载，除非用户刷新，否则调用数据库的数据


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView=inflater.inflate(R.layout.context_home,container,false);
        initViewPager();

        mainDB=MainDB.getInstance(getActivity());
        checkNetWork();
        //是否为第一次加载
        SharedPreferences.Editor editor=getActivity()
                .getSharedPreferences(Config.SHARE_HOME, Context.MODE_PRIVATE).edit();
        editor.putBoolean(Config.SHARE_HOME_ISFIRST_LOAD,true);
        editor.commit();

        initListView();
        return rootView;
    }


    private Handler viewHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            viewPager.setCurrentItem(msg.what);
            super.handleMessage(msg);
        }
    };

    /*
    * 检查网络
    * */
    private void checkNetWork(){
        if (!NetWorkState.isNetworkOpen(getActivity())){
            new AlertDialog.Builder(getActivity()).setTitle("提示")
                    .setMessage("网络连接有问题，是否浏览离线数据？")
                    .setPositiveButton("确定", null)
                    .setNegativeButton("退出", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            getActivity().finish();
                        }
                    })
                    .show();
        }
    }

    private void initListView(){
        boolean isFirstLoad=getActivity()
                .getSharedPreferences(Config.SHARE_HOME,Context.MODE_PRIVATE)
                .getBoolean(Config.SHARE_HOME_ISFIRST_LOAD,true);
        if (NetWorkState.isNetworkOpen(getActivity())){
            if (isFirstLoad){

                handlerRestaurantData();
            }else {
                listRestaurant= (ArrayList<Restaurant>) mainDB.selectAllRestaurant();
            }
        }else {
            listRestaurant= (ArrayList<Restaurant>) mainDB.selectAllRestaurant();
        }

        listView= (RefreshListView) rootView.findViewById(R.id.listView_contextHome);
        final HomeItemAdapter homeItemAdapter=new HomeItemAdapter(getActivity(),listRestaurant);
        listView.setAdapter(homeItemAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intentToRestaurant = new Intent(getActivity(), RestaurantActivity.class);
                intentToRestaurant.putExtra(Config.RESTAURANT_ID,
                        String.valueOf(listRestaurant.get(position - 1).getId()));
                intentToRestaurant.putExtra(Config.RESTAURANT_NAME,listRestaurant.get(position-1).getName());
                intentToRestaurant.putExtra(Config.RESTAURANT_ASSESS,listRestaurant.get(position-1).getAssess());
                intentToRestaurant.putExtra(Config.RESTAURANT_ADDRESS,listRestaurant.get(position-1).getAddress());
                intentToRestaurant.putExtra(Config.RESTAURANT_PHOTO,listRestaurant.get(position-1).getPhoto());

                startActivity(intentToRestaurant);
//            }
            }
        });
        listView.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        //获取最新数据
                        if (NetWorkState.isNetworkOpen(getActivity())){
                            handlerRestaurantData();
                        }
//                        //通知界面显示
                        homeItemAdapter.notifyDataSetChanged();
                        //通知listview 刷新数据完毕；
                        listView.refreshComplete();
                    }
                }, 2000);
            }
        });

    }
    /*
    * 加载listView数据
    * */
    private void handlerRestaurantData(){
        if (!NetWorkState.isNetworkOpen(getActivity())){
            return;
        }
        new NetConnection(Config.SEVER_URL, new HttpCallBackListener() {
            @Override
            public void onFinish(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    int state_status=jsonObject.getInt("status");
                    JSONArray dataArray=jsonObject.getJSONArray("data");
                    JSONObject jsonObject1;
                    Restaurant restaurant;
                    listRestaurant.clear();
//                    Restaurant restaurant;
                    ContentValues restaurantValues=new ContentValues(); //把网络的数据存入
                    for (int i=0;i<dataArray.length();i++){
                        jsonObject1=dataArray.getJSONObject(i);

                        int id=jsonObject1.getInt(Config.RESTAURANT_ID);
                        String name=jsonObject1.getString(Config.RESTAURANT_NAME + "");
                        String photo=jsonObject1.getString(Config.RESTAURANT_PHOTO + "");
                        String description=jsonObject1.getString(Config.RESTAURANT_DESCRIPTION + "");
                        String address=jsonObject1.getString(Config.RESTAURANT_ADDRESS + "");
                        String preferential= jsonObject1.getString(Config.RESTAURANT_PREFERENTIAL + "");
                        String status=jsonObject1.getString(Config.RESTAURANT_STATUS + "");
                        int assess=jsonObject1.getInt(Config.RESTAURANT_ASSESS);

                        restaurantValues.put(Config.RESTAURANT_ID, id);
                        restaurantValues.put(Config.RESTAURANT_NAME, name);
                        restaurantValues.put(Config.RESTAURANT_PHOTO, photo);
                        restaurantValues.put(Config.RESTAURANT_DESCRIPTION, description);
                        restaurantValues.put(Config.RESTAURANT_ADDRESS, address);
                        restaurantValues.put(Config.RESTAURANT_PREFERENTIAL, preferential);
                        restaurantValues.put(Config.RESTAURANT_STATUS, status);
                        restaurantValues.put(Config.RESTAURANT_ASSESS,assess);

                        restaurant=new Restaurant(id,name,photo,description,
                                address,status,preferential,assess);
//                        restaurant=new Restaurant(id,name,
//                                address,assess);
                        if (listRestaurant.size()<1){
                            listRestaurant.add(restaurant);
                        }
                        for (int m=0;m<listRestaurant.size();m++){
                            if (!(listRestaurant.get(m).getId()==id)){
                                listRestaurant.add(restaurant);
                                break;
                            }
                        }

                        if (!mainDB.isExitsRestaurantId(new String[]{String.valueOf(id)})){
                            mainDB.insertRestaurant(restaurantValues);
                        }else {
                            mainDB.updateRestaurantInfo(restaurantValues,Config.RESTAURANT_ID+"=?",new String[]{String.valueOf(id)});
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError() {

            }
        },"restaurant","fetchList");
    }

    /*
    *  图片轮播的 方法
    *  */
    private void initViewPager(){
        relativeLayout_viewPager= (RelativeLayout) rootView.findViewById(R.id.relativeLayout_contextHome_viewPager);
        viewPager= (ViewPager) rootView.findViewById(R.id.viewPage_contextHome);
        textView_viewPage_introduce= (TextView) rootView.findViewById(R.id.textView_contextHome_viewPage_introduce);
        viewLists=new ArrayList<View>();
        textView_viewPage_introduce.setText(viewPage_introduce[0]);
        //初始化ImageViewPager
        imageViewsPagers=new ImageView[viewPagerResId.length];
        for (int i=0;i<viewPagerResId.length;i++){
            imageViewsPagers[i]=new ImageView(getActivity());
            imageViewsPagers[i].setBackgroundResource(viewPagerResId[i]);
            viewLists.add(imageViewsPagers[i]);
        }

        imageViewPoints=new ImageView[viewLists.size()];
        for (int j=0;j<pointsId.length;j++){
            imageViewPoints[j]= (ImageView) rootView.findViewById(pointsId[j]);
        }
        pageAdapter=new ViewPageAdapter(getActivity(),viewLists);
        viewPager.setAdapter(pageAdapter);
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }
            @Override
            public void onPageSelected(int position) {
                what.getAndSet(position);
                for (int i = 0; i < imageViewPoints.length; i++) {
                    if (position == i) {
                        imageViewPoints[i].setImageResource(R.drawable.login_point_selected);
                        textView_viewPage_introduce.setText(viewPage_introduce[i]);
                    } else {
                        imageViewPoints[i].setImageResource(R.drawable.login_point);
                    }
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });




        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    viewHandler.sendEmptyMessage(what.get());
//                    viewHandler.sendEmptyMessageAtTime(what.get(),2000);
                    what.incrementAndGet();
                    if (what.get() > imageViewsPagers.length - 1) {
                        what.getAndAdd(-4);
                    }
                    try {
                        Thread.sleep(TIME_VIEWPAGER);
                    } catch (InterruptedException e) {
                    }
                }
            }

        }).start();

    }



}
