package com.sdpt.app.net;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by Z on 2015/10/29.
 */
public class PostJsonNetConnection  {
    public PostJsonNetConnection(final String url,final HttpCallBackListener listener,final String data){
        new AsyncTask<Void,Void,String>() {
            @Override
            protected String doInBackground(Void... voids) {
//                StringBuilder sb=new StringBuilder();
//                sb.append(data);

                try {
                    URLConnection urlConnection=new URL(url).openConnection();
                    //写入数据
                    urlConnection.setDoOutput(true);
                    BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(urlConnection.getOutputStream()));
                    bw.write(data);
                    bw.flush();
                    //读取数据
                    BufferedReader br=new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    String line=null;
                    StringBuilder result=new StringBuilder();
                    while ((line=br.readLine())!=null){
                        result.append(line);
                    }
                    return result.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }


                return null;
            }

            @Override
            protected void onPostExecute(String result) {
                if (result!=null){
                    if (listener!=null){
                        listener.onFinish(result);
                    }
                }else {
                    if (listener!=null){
                        listener.onError();
                    }
                }

                super.onPostExecute(result);
            }
        }.execute();
    }

}
