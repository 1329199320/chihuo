package com.sdpt.app.net.test;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.sdpt.app.R;
import com.sdpt.app.net.HttpBitmap;
import com.sdpt.app.net.HttpCallBackListener;
import com.sdpt.app.net.NetConnection;
import com.sdpt.app.net.PostNetConnection;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Administrator on 2015/10/9.
 */
public class HttpTest extends Activity {
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.http_test);

        TextView textView= (TextView) findViewById(R.id.text_http_test);
        ImageView imageView= (ImageView) findViewById(R.id.imageView_httpTest);
        String urlstr="http://a.hiphotos.baidu.com/image/pic/item/32fa828ba61ea8d30d88fda9910a304e241f58f1.jpg";
        HttpBitmap.setBackground(urlstr,"22pic",imageView);
//        NetConnectionTest();
        postNetConnection();
    }


    private void postNetConnection(){
        new PostNetConnection("http://dingcan.coding.io/api/food/fetchFoodCatList",
                new HttpCallBackListener() {
                    @Override
                    public void onFinish(String response) {
                        System.out.println("________________"+response);
                    }

                    @Override
                    public void onError() {

                    }
                },"rid","1");
    }


    private void NetConnectionTest(){
        String s="http://dingcan.coding.io/api";
//        final String[] str = new String[1];
        new NetConnection(s, new HttpCallBackListener() {
            @Override
            public void onFinish(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    String info =jsonObject.getString("info");
                    System.out.println("----------------------"+ info);
                    System.out.println(response.toString());
                    Log.i("app","--------------------"+info);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError() {

            }
        },"restaurant","fetchList");
    }

    private void httpTest(){
        new Thread(new Runnable() {
            @Override
            public void run() {
           String info="";
            StringBuilder response=new StringBuilder();
                try {
            URL url=new URL("http://kazamigakuen.oicp.net/Api/Restaurant/demolist/act/getlist");
            HttpURLConnection connection= (HttpURLConnection) url.openConnection();
//            connection.setRequestMethod("GET");
            InputStream inputStream=connection.getInputStream();
            BufferedReader reader=new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line=reader.readLine())!=null){
                response.append(line);
            }
            JSONObject jsonObject=new JSONObject(response.toString());
            info=jsonObject.getString("info");
                    Log.i("app","-----------------------"+info);
                    System.out.println("----------------------"+info);
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
        catch (JSONException e) {
            e.printStackTrace();
        }

            }
        }).start();
    }
}
