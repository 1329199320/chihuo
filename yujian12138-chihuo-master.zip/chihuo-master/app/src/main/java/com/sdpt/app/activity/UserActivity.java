package com.sdpt.app.activity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.sdpt.app.Config;
import com.sdpt.app.R;

/**
 * Created by Z on 2015/10/31.
 * 用户管理
 */
public class UserActivity extends AppCompatActivity {

    private Button btn_exitAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();
        initEvent();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void initEvent(){
        btn_exitAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=getSharedPreferences(Config.APP_ID,MODE_PRIVATE).edit();
                editor.putString(Config.USER_ID,"");
                editor.putString(Config.USER_NAME,"");
                editor.commit();
                finish();

            }
        });


    }

    private void init(){
        btn_exitAccount= (Button) findViewById(R.id.btn_user_exitAccount);
    }

}
