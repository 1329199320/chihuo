package com.sdpt.app.item;

/**
 * Created by Z on 2015/10/30.
 */
public class ResOrderSelectedFood {
    private int id;
    private String name;
    private int count;
    private float singlePrice;
    public ResOrderSelectedFood(int id,String name,int count,float singlePrice){
        this.id=id;this.name=name;this.count=count; this.singlePrice=singlePrice;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setSinglePrice(float singlePrice) {
        this.singlePrice = singlePrice;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getCount() {
        return count;
    }

    public float getSinglePrice() {
        return singlePrice;
    }

}
