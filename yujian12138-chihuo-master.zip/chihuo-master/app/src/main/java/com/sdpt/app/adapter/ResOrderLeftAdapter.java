package com.sdpt.app.adapter;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.sdpt.app.R;
import com.sdpt.app.item.ResOrderFoodItem;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/17.
 */
public class ResOrderLeftAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<ResOrderFoodItem> list;
    private  ViewHolder viewHolder;
    private int firstPosition=0;

    public ResOrderLeftAdapter(){}

    public ResOrderLeftAdapter(Context context,ArrayList<ResOrderFoodItem> list){
        this.context=context;
        this.list=list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public ResOrderFoodItem getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {

        if (convertView==null){
            convertView= LayoutInflater.from(context).inflate(R.layout.resturant_order_left_item,null);

            viewHolder=new ViewHolder();

            viewHolder.imageView= (ImageView) convertView.findViewById(R.id.imageView_resOrder_leftItem);
            viewHolder.textView= (TextView) convertView.findViewById(R.id.textView_resOrder_leftItem);
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder= (ViewHolder) convertView.getTag();
        }
        viewHolder.textView.setText(list.get(position).getClassName());
        //设置class的图片是否为null ，是则隐藏，否则显示
        if (TextUtils.isEmpty(list.get(position).getClassUrl())) {
            viewHolder.imageView.setVisibility(View.GONE);
        }
        else {
            viewHolder.imageView.setVisibility(View.VISIBLE);
            Picasso.with(context).load(list.get(position).getClassUrl()).
                    resize(30, 30).into(viewHolder.imageView);
        }
        if (firstPosition==position){
            convertView.setBackgroundColor(Color.WHITE);
            viewHolder.textView.setTextColor(Color.RED);
        }


        return convertView;
    }
   class ViewHolder{
        ImageView imageView;
        TextView textView;
    }

}
