package com.sdpt.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.fragment.ContextOrderFragment;
import com.sdpt.app.item.ContextOrderFoodItem;
import com.sdpt.app.item.ContextOrderUserInfoItem;
import com.sdpt.app.model.BanScrollListView;

import java.util.ArrayList;
import java.util.Objects;

public class ContextOrderDetailActivity extends AppCompatActivity implements View.OnClickListener{

    private String order_id;
    //控件
    private LinearLayout linear_restaurant;
    private TextView text_restaurantName;
    private BanScrollListView listView_food;
    private TextView text_totalPrice;
    private TextView text_other_restaurantName;
    private TextView text_other_orderId;
    private TextView text_other_contactInfo;
    private TextView text_other_payType;

    private ContextOrderUserInfoItem userInfoItem;
    private ArrayList<ContextOrderFoodItem> listFoodItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_context_order_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        order_id=getIntent().getStringExtra("order_id");

        init();
        initData();
        handleData();
        initEvent();
    }
    private void init(){
        linear_restaurant= (LinearLayout) findViewById(R.id.linear_conOrderDetail_restaurant);
        text_restaurantName= (TextView) findViewById(R.id.text_conOderDetail_restaurant);
        listView_food= (BanScrollListView) findViewById(R.id.list_conOrderDetail_food);

        text_totalPrice= (TextView) findViewById(R.id.text_conOrderDetail_totalPrice);
        text_other_restaurantName = (TextView) findViewById(R.id.text_conOrderDetail_other_restaurant);
        text_other_orderId= (TextView) findViewById(R.id.text_conOrderDetail_other_orderId);
        text_other_contactInfo= (TextView) findViewById(R.id.text_conOrderDetail_other_contactInfo);
        text_other_payType= (TextView) findViewById(R.id.text_conOrderDetail_other_payType);

    }
    private void initEvent(){
        linear_restaurant.setOnClickListener(this);
    }

    private void initData(){
        for (int i=0;i<ContextOrderFragment.userItems.size();i++){
            if (ContextOrderFragment.userItems.get(i).getOrder_id().equals(order_id)){
                userInfoItem=ContextOrderFragment.userItems.get(i);
                break;
            }
        }
        listFoodItems=ContextOrderFragment.foodMap.get(userInfoItem.getOrder_id());
    }

    private void handleData(){
        //订单明细
        text_restaurantName.setText(userInfoItem.getRestaurant());
        text_totalPrice.setText(userInfoItem.getOrder_price());
        OrderDetailAdapter adapter=new OrderDetailAdapter(this,listFoodItems);
//        String[] data=new String[]{"ddd","sss","ddd","sss","ddd","sss","ddd","sss"};
//        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,data);
        listView_food.setAdapter(adapter);
        //其他信息
        text_other_restaurantName.setText(userInfoItem.getRestaurant());
        text_other_orderId.setText(order_id);
        text_other_payType.setText("货到付款");
        text_other_contactInfo.setText(userInfoItem.getContact_name()+"  "+
        userInfoItem.getContact_sex()+"  "+userInfoItem.getContact_phone()+"  "+
        userInfoItem.getContact_address());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.linear_conOrderDetail_restaurant:
                Intent intent=new Intent(ContextOrderDetailActivity.this,RestaurantActivity.class);
                intent.putExtra(Config.RESTAURANT_ID,
                        String.valueOf(userInfoItem.getRestaurant_id()));
                intent.putExtra(Config.RESTAURANT_NAME,userInfoItem.getRestaurant());
                startActivity(intent);
                break;
        }
    }

    class OrderDetailAdapter extends BaseAdapter{

        private Context context;
        private ArrayList<ContextOrderFoodItem> list;
        public OrderDetailAdapter(Context context,ArrayList<ContextOrderFoodItem> list){
            this.context=context;
            this.list=list;
        }

        @Override
        public int getCount() {
            return list.size();
//            return 0;
        }

        @Override
        public Object getItem(int i) {
            return list.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            if (convertView==null){
                convertView= LayoutInflater.from(context).inflate(R.layout.context_order_detail_list_item,viewGroup,false);
                viewHolder=new ViewHolder();
                viewHolder.name= (TextView) convertView.findViewById(R.id.text_conOrderDetail_listItem_name);
                viewHolder.count= (TextView) convertView.findViewById(R.id.text_conOrderDetail_listItem_count);
                viewHolder.price= (TextView) convertView.findViewById(R.id.text_conOrderDetail_listItem_price);
                convertView.setTag(viewHolder);
            }else {
                viewHolder= (ViewHolder) convertView.getTag();
            }
            ContextOrderFoodItem item=list.get(position);
            viewHolder.name.setText(item.getFood());
            viewHolder.count.setText(String.valueOf(item.getFood_count()));
//            viewHolder.price.setText(item.get);
            return convertView;
        }

        class ViewHolder{
            TextView name;
            TextView count;
            TextView price;

        }

    }



}
