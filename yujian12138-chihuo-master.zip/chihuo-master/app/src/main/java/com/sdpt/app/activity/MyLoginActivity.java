package com.sdpt.app.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.net.HttpCallBackListener;
import com.sdpt.app.net.NetWorkState;
import com.sdpt.app.net.PostNetConnection;
import com.sdpt.app.util.MD5Tool;

import org.json.JSONException;
import org.json.JSONObject;


/*
* 登录页面
* */

public class MyLoginActivity extends AppCompatActivity {

    private Button btn_myLogin_login;
    private TextView text_MyLogin_register;
    private TextView text_myLogin_username,text_myLogin_password;
    private EditText edit_myLogin_username,edit_myLogin_password;
    private static final int REGISTER_REQUEST_CODE=1; //注册请求码

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_login);

//        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initView();
        initEvent();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==android.R.id.home) {
            Intent intent=new Intent();
            intent.putExtra(Config.USER_ID,"");
            intent.putExtra(Config.USER_NAME,"");
            setResult(RESULT_OK, intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

   private void initView(){
       text_myLogin_username= (TextView) findViewById(R.id.text_myLogin_username);
        text_myLogin_password= (TextView) findViewById(R.id.text_myLogin_password);
        edit_myLogin_username= (EditText) findViewById(R.id.edit_myLogin_username);
        edit_myLogin_password= (EditText) findViewById(R.id.edit_myLogin_password);
        btn_myLogin_login= (Button) findViewById(R.id.btn_myLogin_login);
        text_MyLogin_register= (TextView) findViewById(R.id.text_MyLogin_register);

        text_myLogin_username.setText("");
        text_myLogin_password.setText("");
    }

   private void initEvent(){
    //注册跳转按钮
       text_MyLogin_register.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
//               startActivity(new Intent(MyLoginActivity.this,MyRegisterActivity.class));
               startActivityForResult(new Intent(MyLoginActivity.this, MyRegisterActivity.class), REGISTER_REQUEST_CODE);
//               finish();
           }
       });
       //登陆
       btn_myLogin_login.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               if (checkLogin()){
                   login();
               }else {
                   Toast.makeText(MyLoginActivity.this,"请检查输入信息",Toast.LENGTH_LONG).show();
               }
           }
       });

   }
    //检查输入信息
    private boolean checkLogin(){
        boolean userNoEmpty=false;
        if (TextUtils.isEmpty(edit_myLogin_username.getText().toString().trim())){
            text_myLogin_username.setText("账号不能为空");
            userNoEmpty=false;
        }else {
            text_myLogin_username.setText("");
            userNoEmpty=true;
        }
        boolean passwordNoEmpty=false;
        if (TextUtils.isEmpty(edit_myLogin_password.getText().toString().trim())){
            text_myLogin_password.setText("密码不能为空");
            passwordNoEmpty=false;
        }else {
            text_myLogin_password.setText("");
            passwordNoEmpty=true;
        }
        return userNoEmpty&&passwordNoEmpty;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case REGISTER_REQUEST_CODE:
                String id=data.getStringExtra(Config.USER_ID);
                String name=data.getStringExtra(Config.USER_NAME);
//                System.out.println("=============="+id+","+name);
                Intent intent=new Intent();
                intent.putExtra(Config.USER_ID,id);
                intent.putExtra(Config.USER_NAME,name);
                setResult(RESULT_OK, intent);
                finish();
                break;
        }
    }

    //执行网络登陆
    private void login(){
        if (!NetWorkState.isNetworkOpen(this)){
            Toast.makeText(MyLoginActivity.this,"请检查网络",Toast.LENGTH_LONG).show();
            return;
        }

        String username=edit_myLogin_username.getText().toString().trim();
        final String password=edit_myLogin_password.getText().toString().trim();


        new PostNetConnection(Config.POST_LOGIN_URL, new HttpCallBackListener() {
            @Override
            public void onFinish(String response) {
                try {
                    JSONObject json=new JSONObject(response);
                    int firstStatus=json.getInt("status");
                    if (firstStatus==0){
                        Toast.makeText(MyLoginActivity.this,"此用户不存在",Toast.LENGTH_LONG).show();
                        return;
                    }
                    JSONObject json_data=json.getJSONObject("data");
                    int secondStatus=json_data.getInt("status");
                    if (secondStatus==0){
                        Toast.makeText(MyLoginActivity.this,"此用户已被禁止",Toast.LENGTH_LONG).show();
                        return;
                    }
                    String json_id=json_data.getString("id");
                    String json_password=json_data.getString("password");
//                    Toast.makeText(MyLoginActivity.this,json_id+json_password,Toast.LENGTH_LONG).show();
                    String password_md5= MD5Tool.md5(password);
                    //判断密码是否一致
                    if (!json_password.equals(password_md5)){
                        Toast.makeText(MyLoginActivity.this,"密码不正确",Toast.LENGTH_LONG).show();
                        return;
                    }
                    SharedPreferences.Editor editor= getSharedPreferences(Config.APP_ID,MODE_PRIVATE).edit();
                    editor.putString(Config.USER_ID,json_id);
                    editor.putString(Config.USER_NAME,edit_myLogin_username.getText().toString());
                    editor.commit();
//                    SharedPreferences preferences=getSharedPreferences(Config.APP_ID,MODE_PRIVATE);
//                    String getId=preferences.getString(Config.USER_ID,"0");
                    Toast.makeText(MyLoginActivity.this,"登陆成功",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent();
                    intent.putExtra(Config.USER_ID,json_id);
                    intent.putExtra(Config.USER_NAME, edit_myLogin_username.getText().toString());
                    setResult(RESULT_OK, intent);
                    finish();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onError() {

            }
        },Config.POST_USER_NAME,username);

    }




}
