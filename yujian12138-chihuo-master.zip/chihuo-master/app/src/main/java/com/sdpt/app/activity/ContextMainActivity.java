package com.sdpt.app.activity;


import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.sdpt.app.R;
import com.sdpt.app.adapter.DrawerAdapter;
import com.sdpt.app.fragment.ContextHomeFragment;
import com.sdpt.app.fragment.ContextMyFragment;
import com.sdpt.app.fragment.ContextOrderFragment;
import com.sdpt.app.item.DrawerItem;

import java.util.ArrayList;
import java.util.List;

/*
* ContextMainActivity 为程序的主Activity，有三个Fragment（片段）:
* ContextHomeFragment : 首页 页面
 * ContextOrderFragment : 订单  页面
 * ContextMyFragment : 我的 页面
 * */

public class ContextMainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener,
        View.OnClickListener{

    //DrawerLayout 抽屉布局声明 已过时
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ArrayList<DrawerItem> menuLists;
    private DrawerAdapter drawerAdapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mTitle;

    //viewPager 声明
    private ViewPager viewPager;
    private FragmentPagerAdapter mAdapter;
    private List<Fragment> mFragments;      //Fragment 集合
    private LinearLayout layoutHme,layoutOrder,layoutMy;
    private TextView textHome,textOrder,textMy;
    private ImageView imageHome,imageOrder,imageMy;
    private ArrayList<TextView> textViews;
    private ArrayList<ImageView> imageViews;
    private int[] imageWhiteRes=new int[]{R.drawable.ic_home_white_24dp,
            R.drawable.ic_description_white_24dp,R.drawable.ic_person_white_24dp};
    private int[] imageBlackeRes=new int[]{R.drawable.ic_home_black_24dp,
            R.drawable.ic_description_black_24dp,R.drawable.ic_person_black_24dp};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_context_main);
//        drawLayout(); //抽屉事件
        initViewPage();  //ViewPager 事件用于跳转Fragment和选择Fragment
        setSelect(0);    //首次进入为 ContextHomeFragment
        //        getSupportFragmentManager().beginTransaction().add(R.id.frameLayout_context,new ContextFragment())
//                .commit();
//        ColorDrawable colorDrawable=new ColorDrawable(0xffFF1744);
        ColorDrawable colorDrawable=new ColorDrawable(0xff009688);
        ActionBar actionBar=this.getSupportActionBar();
        actionBar.setBackgroundDrawable(colorDrawable);
      }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    private long exitTime = 0;

    //退出程序
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN){
            if((System.currentTimeMillis()-exitTime) > 2000){
                Toast.makeText(getApplicationContext(), "再按一次退出程序", Toast.LENGTH_SHORT).show();
                exitTime = System.currentTimeMillis();
            } else {
                finish();
                System.exit(0);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    private void initViewPage(){
        viewPager= (ViewPager) findViewById(R.id.viewPage_context);
        layoutHme= (LinearLayout) findViewById(R.id.linearLayout_contextBottom_home);
        layoutOrder= (LinearLayout) findViewById(R.id.linearLayout_contextBottom_order);
        layoutMy= (LinearLayout) findViewById(R.id.linearLayout_contextBottom_my);
        textHome= (TextView) findViewById(R.id.text_contextBottom_home);
        textOrder= (TextView) findViewById(R.id.text_contextBottom_order);
        textMy= (TextView) findViewById(R.id.text_contextBottom_my);
        imageHome= (ImageView) findViewById(R.id.image_contextBottom_home);
        imageOrder= (ImageView) findViewById(R.id.image_contextBottom_order);
        imageMy= (ImageView) findViewById(R.id.image_contextBottom_my);

        textViews=new ArrayList<>();
        textViews.add(textHome);
        textViews.add(textOrder);
        textViews.add(textMy);

        imageViews=new ArrayList<>();
        imageViews.add(imageHome);
        imageViews.add(imageOrder);
        imageViews.add(imageMy);

        layoutHme.setOnClickListener(this);
        layoutOrder.setOnClickListener(this);
        layoutMy.setOnClickListener(this);

        mFragments = new ArrayList<Fragment>();
        Fragment homeFragment=new ContextHomeFragment();
        Fragment orderFragment=new ContextOrderFragment();
        Fragment myFragment=new ContextMyFragment();
        mFragments.add(homeFragment);
        mFragments.add(orderFragment);
        mFragments.add(myFragment);

        mAdapter=new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return mFragments.get(position);
            }


            @Override
            public int getCount() {
                return mFragments.size();
            }
        };
        viewPager.setAdapter(mAdapter);
        //设置viewPager 的监听事件
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int arg0) {
                int currentItem = viewPager.getCurrentItem();
                setTab(currentItem);
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override
            public void onPageScrollStateChanged(int arg0) {
            }
        });
    }
    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.linearLayout_contextBottom_home:
                setSelect(0);
                break;
            case R.id.linearLayout_contextBottom_order:
                setSelect(1);
                break;
            case R.id.linearLayout_contextBottom_my:
                setSelect(2);
                break;
        }
    }
    private void setSelect(int i)
    {
        setTab(i);
        viewPager.setCurrentItem(i);
    }
    /* 当选择Fragment时 Fragment 字体颜色的变化
    * */
    private void setTab(int i)
    {

        for (int n=0;n<3;n++){
            if (n==i){
                textViews.get(n).setTextColor(Color.RED);
                imageViews.get(n).setImageResource(imageWhiteRes[n]);
            }else {
                textViews.get(n).setTextColor(Color.BLACK);
                imageViews.get(n).setImageResource(imageBlackeRes[n]);
            }
        }

    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
    }


}
