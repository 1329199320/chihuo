package com.sdpt.app.item;

/**
 * Created by Z on 2015/10/31.
 */
public class MyAddressItem {

    private int id;
    private String contactName;
    private String sex;
    private String phone;
    private String address;
    private String addressDetail;
    private String updateTime;

    public MyAddressItem(int id,String contactName,String sex,String phone,
                       String  address,String addressDetail){
        this.id=id;this.contactName=contactName;
        this.phone=phone;this.address=address;
        this.addressDetail=addressDetail;
    }

    public MyAddressItem(int id,String contactName,String sex,String phone,
                         String  address,String addressDetail,String updateTime){
        this.id=id;this.contactName=contactName;
        this.sex=sex;
        this.phone=phone;this.address=address;
        this.addressDetail=addressDetail;
        this.updateTime=updateTime;
    }


    //set方法
    public void setId(int id) {
        this.id = id;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setAddressDetail(String addressDetail) {
        this.addressDetail = addressDetail;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    //get方法


    public int getId() {
        return id;
    }

    public String getContactName() {
        return contactName;
    }

    public String getSex() {
        return sex;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getAddressDetail() {
        return addressDetail;
    }

    public String getUpdateTime() {
        return updateTime;
    }
}
