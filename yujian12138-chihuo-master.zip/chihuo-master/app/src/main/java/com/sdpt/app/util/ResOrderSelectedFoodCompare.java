package com.sdpt.app.util;

import com.sdpt.app.item.ResOrderSelectedFood;

import java.util.Comparator;

/**
 * Created by Z on 2015/10/30.
 */
public class ResOrderSelectedFoodCompare implements Comparator<ResOrderSelectedFood> {

//    class TempRestauanrtCompare implements Comparator<TempRestaurant> {

        @Override
        public int compare(ResOrderSelectedFood t1, ResOrderSelectedFood t2) {
            if (t1.getId()>t2.getId()){
                return 1;
            }
            if (t1.getId()<t2.getId()){
                return -1;
            }
            else
                return 0;

        }


//    }
}
