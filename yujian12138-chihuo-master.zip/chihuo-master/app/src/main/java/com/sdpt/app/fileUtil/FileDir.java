package com.sdpt.app.fileUtil;

import android.os.Environment;

import com.sdpt.app.Config;

import java.io.File;

/**
 * Created by Administrator on 2015/10/10.
 */
public class FileDir  {
    public static File getImageDir(){
        File imageFile=new File(getAppDir(),"image");
        if (!imageFile.exists()){
            imageFile.mkdirs();
        }

        return imageFile;
    }
    public static File getAppDir(){
        File dir = new File(Environment.getExternalStorageDirectory(), Config.FILE_DIR_APP);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
