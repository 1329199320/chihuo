package com.sdpt.app.net;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.text.TextUtils;
import android.widget.ImageView;

import com.sdpt.app.fileUtil.FileDir;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Administrator on 2015/10/10.
 * HttpBitmap 为网络加载图片类
 */
public class HttpBitmap {
    /*
    * @param String url 图片的地址
    * @param ImageView imageView ImageView控件
    * 注 ：此方法会直接从后台给ImageView设置背景图片
    * */
    public  static void setBackground(final String url,final String saveUrl,final ImageView imageView){
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... voids) {
                URL myFileURL;
                Bitmap bitmap=null;
                try{
                    myFileURL = new URL(url);
                    //获得连接
                    HttpURLConnection conn=(HttpURLConnection)myFileURL.openConnection();
                    //设置超时时间为6000毫秒，conn.setConnectionTiem(0);表示没有时间限制
                    conn.setConnectTimeout(6000);
                    //连接设置获得数据流
                    conn.setDoInput(true);
                    //不使用缓存
                    conn.setUseCaches(false);
                    //得到数据流
                    InputStream is = conn.getInputStream();
                    //解析得到图片
                    bitmap = BitmapFactory.decodeStream(is);
                    saveImage(saveUrl,bitmap);
                    //关闭数据流
                    is.close();
                    return bitmap;
                }catch(Exception e){
                    e.printStackTrace();
                }

                return null;
            }

            @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
            @Override
            protected void onPostExecute(Bitmap bitmap) {
                Drawable drawable=new BitmapDrawable(bitmap);
                imageView.setBackground(drawable);
                super.onPostExecute(bitmap);
            }
        }.execute();
    }

    public static void setBitmap(final String url,final ImageView imageView){
        if (TextUtils.isEmpty(url)||imageView==null){
            return;
        }
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... voids) {
                URL myFileURL;
                Bitmap bitmap=null;
                try{
                    myFileURL = new URL(url);
                    //获得连接
                    HttpURLConnection conn=(HttpURLConnection)myFileURL.openConnection();
                    conn.setConnectTimeout(6000);
                    conn.setDoInput(true);
                    conn.setUseCaches(false);
                    InputStream is = conn.getInputStream();
                    bitmap = BitmapFactory.decodeStream(is);
                    is.close();
                    return bitmap;
                }catch(Exception e){
                    e.printStackTrace();
                }
                return null;
            }

            @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
            @Override
            protected void onPostExecute(Bitmap bitmap) {
                Drawable drawable=new BitmapDrawable(bitmap);
                imageView.setBackground(drawable);
                super.onPostExecute(bitmap);
            }
        }.execute();
    }

    public static void saveImage(String url,Bitmap bitmap)  {
        File dirFile= FileDir.getImageDir();
        File file=new File(dirFile, url+".jpg");
        if (!file.exists()){
            try {
                file.createNewFile();
                BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                bos.flush();
                bos.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
