package com.sdpt.app.item;

/**
 * Created by Administrator on 2015/10/9.
 *
 *  餐厅类
 */
public class Restaurant {
    private int id;   //餐厅Id
    private String name; //餐厅名
    private String photo; // 餐厅本地图片地址
    private String description; //商家描述
    private String address; //商家地址
    private String status; //  商家状态
    private String preferential; //优惠
    private int assess; //评价

    public Restaurant(){

    }
    public Restaurant(int id,String name,String address,int assess){
        this.id=id;this.name=name;
        this.address=address;this.assess=assess;

    }
    public Restaurant(int id,String name,String photo,String description,
                      String address,String status,String preferential,int assess){
        this.id=id; this.name=name;this.photo=photo;this.description=description;
        this.address=address;this.status=status;this.preferential=preferential;this.assess=assess;

    }

    public void setAssess(int assess) {
        this.assess = assess;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPreferential(String preferential) {
        this.preferential = preferential;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getPreferential() {
        return preferential;
    }

    public String getStatus() {
        return status;
    }

    public int getAssess() {
        return assess;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoto() {
        return photo;
    }
}
