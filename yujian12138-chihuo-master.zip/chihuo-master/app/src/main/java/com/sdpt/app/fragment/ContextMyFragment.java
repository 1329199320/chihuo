package com.sdpt.app.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sdpt.app.Config;
import com.sdpt.app.R;
import com.sdpt.app.activity.MyAddressActivity;
import com.sdpt.app.activity.MyLoginActivity;
import com.sdpt.app.activity.UserActivity;

/**
 * Created by Administrator on 2015/10/6.
 */
public class ContextMyFragment extends Fragment {

    private View rootView;
    private Button btn_login;
    private LinearLayout linear_unLogin,linear_login,linear_address;
    private TextView text_name;
    private static final int LOGIN_REQUESR_CODE=0;
    private String userId="";
    private String username="";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView=inflater.inflate(R.layout.context_my,container,false);

        init();
        initEvent();
        getUserInfo();
        changeLoginState();

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        getUserInfo();
        changeLoginState();
    }

    private void getUserInfo(){
        SharedPreferences sharedPreferences=getActivity().getSharedPreferences(Config.APP_ID, Context.MODE_PRIVATE);
        userId=sharedPreferences.getString(Config.USER_ID,"");
        username=sharedPreferences.getString(Config.USER_NAME,"");
    }
    
    private void init(){
        btn_login = (Button) rootView.findViewById(R.id.btn_contextMy_login);
        linear_unLogin= (LinearLayout) rootView.findViewById(R.id.linear_contextMy_unLogin);
        linear_login= (LinearLayout) rootView.findViewById(R.id.linear_contextMy_login);
        text_name= (TextView) rootView.findViewById(R.id.text_contextMy_username);

        linear_address= (LinearLayout) rootView.findViewById(R.id.linear_ContextMy_address);
    }
    private void initEvent(){

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(getActivity(),MyLoginActivity.class),LOGIN_REQUESR_CODE);
            }
        });
        text_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), UserActivity.class));
            }
        });

        linear_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkIsLogin(new MyAddressActivity());
            }
        });


    }

    private void checkIsLogin(Activity activity){
        if (TextUtils.isEmpty(userId)){
            Toast.makeText(getActivity(),"请先登录",Toast.LENGTH_SHORT).show();
            startActivityForResult(new Intent(getActivity(),MyLoginActivity.class),LOGIN_REQUESR_CODE);
        }else {
            startActivity(new Intent(getActivity(),activity.getClass()));
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        System.out.println("++++++++++"+requestCode+","+resultCode+","+data.toString());
//        switch (requestCode){
//            case LOGIN_REQUESR_CODE:
//                userId=data.getStringExtra(Config.USER_ID);
//                username=data.getStringExtra(Config.USER_NAME);
//                changeLoginState();
//                break;
//        }
    }

    private void changeLoginState(){
        if (TextUtils.isEmpty(userId)){
            linear_unLogin.setVisibility(View.VISIBLE);
            linear_login.setVisibility(View.GONE);
        }else {
            linear_login.setVisibility(View.VISIBLE);
            linear_unLogin.setVisibility(View.GONE);

            text_name.setText(username);
        }
    }

}
