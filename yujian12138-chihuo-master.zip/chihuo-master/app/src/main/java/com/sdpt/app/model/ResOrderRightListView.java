package com.sdpt.app.model;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * Created by Administrator on 2015/10/17.
 *
 */
public class ResOrderRightListView extends ListView {
    public ResOrderRightListView(Context context) {
        super(context);
    }

    public ResOrderRightListView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ResOrderRightListView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
